# NightPvP VoteSystem 1.0.0

Ziel: Paper 1.21.8 / Java 21

## Hauptfunktionen
- `/vote` 3x9 GUI mit Vote-Seiten, Vote-Anzahl, Streak und VoteParty-Fortschritt.
- NuVotifier/Votifier-Integration über den Bukkit `VotifierEvent` (Soft-Dependency, dynamischer Hook).
- Vote-Key = `TRIPWIRE_HOOK` mit NightPvP-PDC-ID.
- Normale Vote-Belohnung: standardmäßig 1 Vote-Key + 2.500$ + 3 Diamanten + 8 Eisen + 16 Erfahrungsfläschchen; komplett ingame änderbar.
- Offline-Votes/Pending Rewards in SQLite.
- Doppelte Vote-Events werden über eine eindeutige SHA-256-Kennung ignoriert.
- Vote-Streak mit standardmäßig 3/7/14/30 Tagen, Rewards ingame änderbar.
- Globale VoteParty (Standard 100 Votes) mit editierbaren Meilensteinen.
- VoteParty GiveAll an alle Online-Spieler + dekorative Item-Sprüh-Animation am Spawn + Feuerwerk.
- Normale CHEST als Vote-Kiste, automatisch geschütztes Hologramm.
- Linksklick Vote-Kiste = Preview; Rechtsklick mit Vote-Key = Roulette.
- Roulette: komplette mittlere 9er-Reihe, verlangsamt sich, Slot 13 ist Gewinn.
- Seltenheiten: Gewöhnlich / Selten / Sehr selten / Legendär mit abgestuften Effekten.
- Vote-Kisten-Rewards: Item, Pack, Guthaben oder Vote-Key; ingame editierbar.
- Pack-Anbindung an `NightPvP-PackSystem` 3.5.x per Reflection (`PackService#add`, `exists`, `ids`).
- Guthaben-Anbindung an `NightPvPGuthabenAPI#addBalance`.

## Installation
1. Server komplett stoppen. Kein `/reload`.
2. `NightPvP-VoteSystem-1.0.0-Paper1.21.8.jar` in `plugins/` legen.
3. NuVotifier installieren/konfigurieren (Pluginname `Votifier`).
4. NightPvP-Guthaben und NightPvP-PackSystem installiert lassen, wenn Geld-/Pack-Rewards verwendet werden.
5. Server starten.
6. Normale Kiste am Spawn platzieren, ansehen und `/voteadmin crate set` ausführen.
7. Voteparty-Animationspunkt optional mit `/voteadmin party location set` setzen.
8. Vote-Seiten mit `/voteadmin site add <ID> <Name> <URL>` eintragen und den NuVotifier-Service mit `/voteadmin site service <ID> <ServiceName>` abgleichen.

## Wichtige Adminbefehle
Siehe `/voteadmin` ingame. Enthalten sind u.a. Site-, VoteReward-, Key-, Crate-, Roulette-Reward-, Party-, Streak-, Broadcast- und Test-Verwaltung.

### Pack als Vote-Kisten-Gewinn
`/voteadmin reward pack add <ID> <Pack> <Anzahl>`

### Pack als normale Vote-Belohnung
`/voteadmin votereward pack add <Pack> <Anzahl>`

### Pack als VoteParty-Belohnung
`/voteadmin party pack add <Pack> <Anzahl>`

## Daten
- `plugins/NightPvP-VoteSystem/votes.db`: verarbeitete Votes, Gesamtvotes, Streaks, VoteParty-Zähler, Pending Rewards.
- `plugins/NightPvP-VoteSystem/settings.yml`: ingame änderbare Seiten, Reward-Pools, Kisten-/Party-Standorte und Einstellungen.

## Sichere Reward-Editoren
`/voteadmin votereward`, `/voteadmin party reward` und die Streak-Reward-GUIs verwenden einen Template-Editor: Linksklick kopiert das Item aus der Haupthand in den Reward-Slot, Rechtsklick entfernt es. Das echte Item wird nicht verbraucht und konfigurierte Reward-Items können nicht aus der GUI herausgenommen werden.
