package de.nightpvp.vote;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import java.util.List;

public final class VoteCommand implements TabExecutor {
    private final GuiManager gui;
    public VoteCommand(GuiManager gui){this.gui=gui;}
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        if(!(sender instanceof Player p)){sender.sendMessage(Text.vote("Dieser Befehl ist nur ingame verfügbar."));return true;}
        gui.openVote(p);return true;
    }
    @Override public List<String> onTabComplete(CommandSender sender,Command command,String alias,String[] args){return List.of();}
}
