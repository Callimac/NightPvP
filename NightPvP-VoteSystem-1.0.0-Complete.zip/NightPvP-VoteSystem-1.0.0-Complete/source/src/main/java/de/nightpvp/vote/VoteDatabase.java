package de.nightpvp.vote;

import java.io.File;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;

public final class VoteDatabase implements AutoCloseable {
    public record StreakUpdate(int streak, boolean changedToday) {}
    public record Pending(long id, String payload) {}

    private final NightPvPVotePlugin plugin;
    private Connection connection;

    public VoteDatabase(NightPvPVotePlugin plugin) { this.plugin=plugin; }

    public void open() throws Exception {
        if(!plugin.getDataFolder().exists())plugin.getDataFolder().mkdirs();
        Class.forName("org.sqlite.JDBC");
        File db=new File(plugin.getDataFolder(),"votes.db");
        connection=DriverManager.getConnection("jdbc:sqlite:"+db.getAbsolutePath());
        try(Statement st=connection.createStatement()){
            st.execute("PRAGMA journal_mode=WAL"); st.execute("PRAGMA synchronous=NORMAL");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS processed_votes (vote_key TEXT PRIMARY KEY, uuid TEXT NOT NULL, name TEXT NOT NULL, service TEXT NOT NULL, vote_time TEXT NOT NULL, processed_at INTEGER NOT NULL)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS totals (uuid TEXT PRIMARY KEY, name TEXT NOT NULL, votes INTEGER NOT NULL DEFAULT 0)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS streaks (uuid TEXT PRIMARY KEY, name TEXT NOT NULL, streak INTEGER NOT NULL DEFAULT 0, last_day TEXT)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS state (key TEXT PRIMARY KEY, value TEXT NOT NULL)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS pending_rewards (id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT NOT NULL, payload TEXT NOT NULL, created_at INTEGER NOT NULL)");
            st.executeUpdate("CREATE INDEX IF NOT EXISTS idx_pending_uuid ON pending_rewards(uuid)");
        }
        ensureState("party_votes","0");
    }

    private void ensureState(String key,String value)throws SQLException{try(PreparedStatement p=connection.prepareStatement("INSERT OR IGNORE INTO state(key,value) VALUES(?,?)")){p.setString(1,key);p.setString(2,value);p.executeUpdate();}}

    public synchronized boolean registerVote(String key,UUID uuid,String name,String service,String voteTime){
        try(PreparedStatement p=connection.prepareStatement("INSERT INTO processed_votes(vote_key,uuid,name,service,vote_time,processed_at) VALUES(?,?,?,?,?,?)")){
            p.setString(1,key);p.setString(2,uuid.toString());p.setString(3,name);p.setString(4,service);p.setString(5,voteTime);p.setLong(6,System.currentTimeMillis());p.executeUpdate();return true;
        }catch(SQLException e){if(e.getMessage()!=null&&e.getMessage().toLowerCase(Locale.ROOT).contains("unique"))return false;plugin.getLogger().severe("Vote konnte nicht gespeichert werden: "+e.getMessage());return false;}
    }

    public synchronized int incrementTotal(UUID uuid,String name){
        try(PreparedStatement p=connection.prepareStatement("INSERT INTO totals(uuid,name,votes) VALUES(?,?,1) ON CONFLICT(uuid) DO UPDATE SET name=excluded.name,votes=votes+1")){p.setString(1,uuid.toString());p.setString(2,name);p.executeUpdate();}catch(SQLException e){plugin.getLogger().severe("Vote-Zähler Fehler: "+e.getMessage());}
        return total(uuid);
    }
    public synchronized int total(UUID uuid){try(PreparedStatement p=connection.prepareStatement("SELECT votes FROM totals WHERE uuid=?")){p.setString(1,uuid.toString());try(ResultSet r=p.executeQuery()){return r.next()?r.getInt(1):0;}}catch(SQLException e){return 0;}}

    public synchronized StreakUpdate updateStreak(UUID uuid,String name,LocalDate today){
        int current=0; LocalDate last=null;
        try(PreparedStatement p=connection.prepareStatement("SELECT streak,last_day FROM streaks WHERE uuid=?")){p.setString(1,uuid.toString());try(ResultSet r=p.executeQuery()){if(r.next()){current=r.getInt(1);String s=r.getString(2);if(s!=null)try{last=LocalDate.parse(s);}catch(DateTimeParseException ignored){}}}}catch(SQLException ignored){}
        if(today.equals(last))return new StreakUpdate(current,false);
        int next=(last!=null&&today.minusDays(1).equals(last))?Math.max(1,current+1):1;
        try(PreparedStatement p=connection.prepareStatement("INSERT INTO streaks(uuid,name,streak,last_day) VALUES(?,?,?,?) ON CONFLICT(uuid) DO UPDATE SET name=excluded.name,streak=excluded.streak,last_day=excluded.last_day")){p.setString(1,uuid.toString());p.setString(2,name);p.setInt(3,next);p.setString(4,today.toString());p.executeUpdate();}catch(SQLException e){plugin.getLogger().warning("Streak konnte nicht gespeichert werden: "+e.getMessage());}
        return new StreakUpdate(next,true);
    }
    public synchronized int streak(UUID uuid){try(PreparedStatement p=connection.prepareStatement("SELECT streak FROM streaks WHERE uuid=?")){p.setString(1,uuid.toString());try(ResultSet r=p.executeQuery()){return r.next()?r.getInt(1):0;}}catch(SQLException e){return 0;}}

    public synchronized int partyVotes(){return Integer.parseInt(state("party_votes","0"));}
    public synchronized int incrementParty(){int v=partyVotes()+1;setState("party_votes",Integer.toString(v));return v;}
    public synchronized void resetParty(){setState("party_votes","0");}
    public synchronized void setParty(int v){setState("party_votes",Integer.toString(Math.max(0,v)));}
    private String state(String k,String def){try(PreparedStatement p=connection.prepareStatement("SELECT value FROM state WHERE key=?")){p.setString(1,k);try(ResultSet r=p.executeQuery()){return r.next()?r.getString(1):def;}}catch(SQLException e){return def;}}
    private void setState(String k,String v){try(PreparedStatement p=connection.prepareStatement("INSERT INTO state(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value")){p.setString(1,k);p.setString(2,v);p.executeUpdate();}catch(SQLException e){plugin.getLogger().warning("State konnte nicht gespeichert werden: "+e.getMessage());}}

    public synchronized void addPending(UUID uuid,RewardBundle b){if(b==null||b.empty())return;try(PreparedStatement p=connection.prepareStatement("INSERT INTO pending_rewards(uuid,payload,created_at) VALUES(?,?,?)")){p.setString(1,uuid.toString());p.setString(2,BundleCodec.encode(b));p.setLong(3,System.currentTimeMillis());p.executeUpdate();}catch(SQLException e){plugin.getLogger().severe("Pending Reward konnte nicht gespeichert werden: "+e.getMessage());}}
    public synchronized List<Pending> pending(UUID uuid){List<Pending>out=new ArrayList<>();try(PreparedStatement p=connection.prepareStatement("SELECT id,payload FROM pending_rewards WHERE uuid=? ORDER BY id")){p.setString(1,uuid.toString());try(ResultSet r=p.executeQuery()){while(r.next())out.add(new Pending(r.getLong(1),r.getString(2)));}}catch(SQLException e){plugin.getLogger().warning("Pending Rewards konnten nicht gelesen werden: "+e.getMessage());}return out;}
    public synchronized void deletePending(long id){try(PreparedStatement p=connection.prepareStatement("DELETE FROM pending_rewards WHERE id=?")){p.setLong(1,id);p.executeUpdate();}catch(SQLException ignored){}}

    @Override public synchronized void close(){if(connection!=null)try{connection.close();}catch(SQLException ignored){}connection=null;}
}
