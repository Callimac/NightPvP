package de.nightpvp.vote;

public final class Text {
    private Text() {}
    public static String c(String s) { return s == null ? "" : s.replace('&', '§'); }
    public static String vote(String s) { return c("&6&lVOTE &8» &7" + s); }
    public static String party(String s) { return c("&6&lVOTEPARTY &8» &7" + s); }
}
