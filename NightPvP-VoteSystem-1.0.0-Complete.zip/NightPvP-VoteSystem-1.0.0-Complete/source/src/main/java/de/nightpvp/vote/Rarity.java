package de.nightpvp.vote;

import java.util.Locale;

public enum Rarity {
    GEWOEHNLICH("§7Gewöhnlich", 1),
    SELTEN("§bSelten", 2),
    SEHR_SELTEN("§dSehr selten", 3),
    LEGENDAER("§6§lLegendär", 4);

    private final String display;
    private final int level;
    Rarity(String display, int level) { this.display = display; this.level = level; }
    public String display() { return display; }
    public int level() { return level; }

    public static Rarity parse(String raw) {
        if (raw == null) return GEWOEHNLICH;
        String s = raw.toLowerCase(Locale.ROOT).replace("ä", "ae").replace("-", "").replace("_", "").replace(" ", "");
        return switch (s) {
            case "selten" -> SELTEN;
            case "sehrselten" -> SEHR_SELTEN;
            case "legendaer", "legendary" -> LEGENDAER;
            default -> GEWOEHNLICH;
        };
    }
}
