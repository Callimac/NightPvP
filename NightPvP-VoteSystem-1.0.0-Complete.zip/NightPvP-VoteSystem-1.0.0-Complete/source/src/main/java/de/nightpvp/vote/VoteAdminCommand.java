package de.nightpvp.vote;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public final class VoteAdminCommand implements TabExecutor {
    private final NightPvPVotePlugin plugin;private final SettingsStore settings;private final VoteService service;private final GuiManager gui;private final VoteDatabase db;
    private final Map<UUID,Long> clearConfirm=new HashMap<>();private final Map<UUID,Long> resetConfirm=new HashMap<>();
    public VoteAdminCommand(NightPvPVotePlugin plugin,SettingsStore settings,VoteService service,GuiManager gui,VoteDatabase db){this.plugin=plugin;this.settings=settings;this.service=service;this.gui=gui;this.db=db;}

    @Override public boolean onCommand(CommandSender s,Command c,String l,String[] a){
        if(!s.hasPermission("nightpvp.vote.admin")){s.sendMessage(Text.vote("§cDafür hast du keine Berechtigung!"));return true;}
        if(a.length==0){help(s);return true;}String sub=a[0].toLowerCase(Locale.ROOT);
        try{return switch(sub){case "status"->status(s);case "site"->site(s,a);case "votereward"->voteReward(s,a);case "key"->key(s,a);case "crate"->crate(s,a);case "reward"->reward(s,a);case "party"->party(s,a);case "broadcast"->broadcast(s,a);case "streak"->streak(s,a);case "test"->test(s,a);case "reload"->reload(s);default->{help(s);yield true;}};}catch(Exception e){s.sendMessage(Text.vote("§cFehler: "+e.getMessage()));plugin.getLogger().warning("/voteadmin Fehler: "+e);return true;}
    }

    private boolean status(CommandSender s){s.sendMessage(Text.vote("Status: §e"+db.partyVotes()+"§8/§6"+settings.partyThreshold()+" §7Voteparty-Votes, §e"+settings.sites().size()+" §7Seiten, §e"+settings.crateRewards().size()+" §7Kisten-Rewards, Broadcast "+onOff(settings.voteBroadcast())));return true;}

    private boolean site(CommandSender s,String[] a){
        if(a.length<2){s.sendMessage(Text.vote("§cVerwendung: /voteadmin site <add|remove|list|url|name|service|enable> ..."));return true;}String op=a[1].toLowerCase(Locale.ROOT);
        if(op.equals("list")){s.sendMessage(Text.vote("Vote-Seiten:"));for(VoteSite v:settings.sites())s.sendMessage(Text.c("&8» &d"+v.id()+" &8• &f"+v.name()+" &8• "+(v.enabled()?"&aan":"&caus")+" &8• &7"+v.service()));return true;}
        if(op.equals("add")&&a.length>=5){String id=safeId(a[2]);String name=a[3];String url=a[4];if(id==null||!url(url)){s.sendMessage(Text.vote("§cUngültige ID oder URL (http/https)."));return true;}settings.saveSite(new VoteSite(id,name,url,name,true));s.sendMessage(Text.vote("Vote-Seite §e"+id+" §7wurde hinzugefügt."));return true;}
        if(a.length<3){s.sendMessage(Text.vote("§cEs fehlt eine Seiten-ID."));return true;}VoteSite old=settings.site(a[2]);if(old==null){s.sendMessage(Text.vote("§cDiese Vote-Seite existiert nicht."));return true;}
        switch(op){case "remove"->{settings.removeSite(old.id());s.sendMessage(Text.vote("Vote-Seite wurde entfernt."));}case "url"->{if(a.length<4||!url(a[3])){s.sendMessage(Text.vote("§cUngültige URL."));break;}settings.saveSite(new VoteSite(old.id(),old.name(),a[3],old.service(),old.enabled()));s.sendMessage(Text.vote("URL wurde geändert."));}case "name"->{if(a.length<4)break;settings.saveSite(new VoteSite(old.id(),a[3],old.url(),old.service(),old.enabled()));s.sendMessage(Text.vote("Name wurde geändert."));}case "service"->{if(a.length<4)break;settings.saveSite(new VoteSite(old.id(),old.name(),old.url(),a[3],old.enabled()));s.sendMessage(Text.vote("NuVotifier-Service wurde auf §e"+a[3]+" §7gesetzt."));}case "enable"->{if(a.length<4)break;boolean v=on(a[3]);settings.saveSite(new VoteSite(old.id(),old.name(),old.url(),old.service(),v));s.sendMessage(Text.vote("Vote-Seite ist jetzt "+onOff(v)+"§7."));}default->s.sendMessage(Text.vote("§cUnbekannte Site-Aktion."));}return true;
    }

    private boolean voteReward(CommandSender s,String[] a){
        if(a.length==1){if(s instanceof Player p)gui.openEditor(p,GuiManager.GuiType.EDIT_NORMAL,0);else s.sendMessage(Text.vote("§cDer Item-Editor ist nur ingame verfügbar."));return true;}
        String op=a[1].toLowerCase(Locale.ROOT);if(op.equals("money")&&a.length>=3){long v=longVal(a[2]);settings.setBundleMoney("normal",v);s.sendMessage(Text.vote("Vote-Guthaben: §e"+v+"$"));return true;}if((op.equals("key")||op.equals("keys"))&&a.length>=3){int v=intVal(a[2]);settings.setBundleKeys("normal",v);s.sendMessage(Text.vote("Vote-Keys pro Vote: §e"+v));return true;}
        if(op.equals("pack"))return bundlePack(s,a,"normal",2);s.sendMessage(Text.vote("§cVerwendung: /voteadmin votereward [money <Betrag>|key <Anzahl>|pack ...]"));return true;
    }

    private boolean key(CommandSender s,String[] a){
        if(a.length>=2&&a[1].equalsIgnoreCase("give")&&a.length>=4){Player p=Bukkit.getPlayerExact(a[2]);int amount=intVal(a[3]);if(p==null||amount<1){s.sendMessage(Text.vote("§cSpieler nicht online oder Anzahl ungültig."));return true;}int left=service.giveKeys(p,amount);if(left>0)service.queueKeys(p.getUniqueId(),left);p.playSound(p.getLocation(),org.bukkit.Sound.ENTITY_PLAYER_LEVELUP,1f,1.2f);s.sendMessage(Text.vote("§e"+p.getName()+" §7hat §e"+amount+"x Vote-Key §7erhalten."));return true;}
        if(a.length>=2&&a[1].equalsIgnoreCase("giveall")&&a.length>=3){int amount=intVal(a[2]);if(amount<1){s.sendMessage(Text.vote("§cAnzahl ungültig."));return true;}int count=0;for(Player p:Bukkit.getOnlinePlayers()){int left=service.giveKeys(p,amount);if(left>0)service.queueKeys(p.getUniqueId(),left);p.playSound(p.getLocation(),org.bukkit.Sound.ENTITY_PLAYER_LEVELUP,1f,1.2f);count++;}s.sendMessage(Text.vote("Vote-Key GiveAll: §e"+count+" §7Spieler × §e"+amount));return true;}
        s.sendMessage(Text.vote("§cVerwendung: /voteadmin key give <Spieler> <Anzahl> | /voteadmin key giveall <Anzahl>"));return true;
    }

    private boolean crate(CommandSender s,String[] a){
        if(a.length<2){s.sendMessage(Text.vote("§cVerwendung: /voteadmin crate <set|remove|location|preview>"));return true;}String op=a[1].toLowerCase(Locale.ROOT);
        if(op.equals("set")){if(!(s instanceof Player p)){s.sendMessage(Text.vote("§cNur ingame möglich."));return true;}Block b=p.getTargetBlockExact(6);if(b==null||b.getType()!=Material.CHEST){s.sendMessage(Text.vote("§cSchaue auf eine normale Kiste."));return true;}gui.removeHologram();settings.setCrateLocation(b.getLocation());gui.refreshHologram();s.sendMessage(Text.vote("Vote-Kiste und Hologramm wurden gesetzt."));return true;}
        if(op.equals("remove")){gui.removeHologram();settings.clearCrateLocation();s.sendMessage(Text.vote("Vote-Kiste wurde entfernt."));return true;}
        if(op.equals("location")){var l=settings.crateLocation();s.sendMessage(Text.vote(l==null?"§cKeine Vote-Kiste gesetzt.":"Vote-Kiste: §e"+l.getWorld().getName()+" "+l.getBlockX()+" "+l.getBlockY()+" "+l.getBlockZ()));return true;}
        if(op.equals("preview")&&s instanceof Player p){gui.openPreview(p);return true;}return true;
    }

    private boolean reward(CommandSender s,String[] a){
        if(a.length<2){rewardHelp(s);return true;}String op=a[1].toLowerCase(Locale.ROOT);
        if(op.equals("list")){s.sendMessage(Text.vote("Vote-Kisten-Rewards:"));for(RewardDefinition r:settings.crateRewards())s.sendMessage(Text.c("&8» &d"+r.id()+" &8• &f"+r.displayName()+" &8• "+r.rarity().display()+" &8• &e"+r.chance()+" &8• "+(r.enabled()?"&aan":"&caus")));return true;}
        if(op.equals("clear")){if(a.length>=3&&a[2].equalsIgnoreCase("confirm")&&confirmed(s,clearConfirm)){settings.clearRewards();s.sendMessage(Text.vote("§cAlle Vote-Kisten-Rewards wurden gelöscht."));return true;}mark(s,clearConfirm);s.sendMessage(Text.vote("§cALLE Rewards löschen? Bestätige innerhalb 15s mit §d/voteadmin reward clear confirm"));return true;}
        if(op.equals("add")){if(!(s instanceof Player p)||a.length<3){s.sendMessage(Text.vote("§cItem in die Hand + /voteadmin reward add <ID>"));return true;}String id=safeId(a[2]);ItemStack held=p.getInventory().getItemInMainHand();if(id==null||held==null||held.getType()==Material.AIR){s.sendMessage(Text.vote("§cUngültige ID oder kein Item in der Hand."));return true;}settings.saveReward(new RewardDefinition(id,RewardDefinition.Type.ITEM,held,null,0,held.getAmount(),10.0,Rarity.GEWOEHNLICH,true));s.sendMessage(Text.vote("Item-Reward §e"+id+" §7hinzugefügt."));return true;}
        if(op.equals("pack")&&a.length>=3&&a[2].equalsIgnoreCase("add")&&a.length>=6){String id=safeId(a[3]);String pack=a[4];int amount=intVal(a[5]);if(id==null||amount<1||!service.integrations().packExists(pack)){s.sendMessage(Text.vote("§cUngültige ID, Anzahl oder Pack."));return true;}settings.saveReward(new RewardDefinition(id,RewardDefinition.Type.PACK,null,pack,0,amount,10.0,Rarity.SELTEN,true));s.sendMessage(Text.vote("Pack-Reward §e"+id+" §7hinzugefügt."));return true;}
        if(op.equals("money")&&a.length>=3&&a[2].equalsIgnoreCase("add")&&a.length>=5){String id=safeId(a[3]);long money=longVal(a[4]);if(id==null||money<1)return true;settings.saveReward(new RewardDefinition(id,RewardDefinition.Type.MONEY,null,null,money,1,10.0,Rarity.SELTEN,true));s.sendMessage(Text.vote("Guthaben-Reward hinzugefügt."));return true;}
        if(op.equals("key")&&a.length>=3&&a[2].equalsIgnoreCase("add")&&a.length>=5){String id=safeId(a[3]);int amount=intVal(a[4]);if(id==null||amount<1)return true;settings.saveReward(new RewardDefinition(id,RewardDefinition.Type.KEY,null,null,0,amount,10.0,Rarity.SELTEN,true));s.sendMessage(Text.vote("Vote-Key-Reward hinzugefügt."));return true;}
        if(a.length<3){rewardHelp(s);return true;}RewardDefinition r=settings.crateReward(a[2]);if(r==null){s.sendMessage(Text.vote("§cReward nicht gefunden."));return true;}
        switch(op){case "remove"->{settings.removeReward(r.id());s.sendMessage(Text.vote("Reward entfernt."));}case "chance"->{if(a.length<4)break;double v=doubleVal(a[3]);settings.saveReward(r.withChance(v));s.sendMessage(Text.vote("Chance/Gewichtung von §e"+r.id()+" §7= §e"+v));}case "amount"->{if(a.length<4)break;int v=intVal(a[3]);settings.saveReward(r.withAmount(v));s.sendMessage(Text.vote("Menge geändert."));}case "rarity"->{if(a.length<4)break;settings.saveReward(r.withRarity(Rarity.parse(a[3])));s.sendMessage(Text.vote("Seltenheit geändert."));}case "enable"->{if(a.length<4)break;boolean v=on(a[3]);settings.saveReward(r.withEnabled(v));s.sendMessage(Text.vote("Reward ist jetzt "+onOff(v)+"§7."));}case "clone"->{if(a.length<4)break;String id=safeId(a[3]);if(id!=null){settings.saveReward(r.copyAs(id));s.sendMessage(Text.vote("Reward wurde als §e"+id+" §7kopiert."));}}default->rewardHelp(s);}return true;
    }

    private boolean party(CommandSender s,String[] a){
        if(a.length<2){partyHelp(s);return true;}String op=a[1].toLowerCase(Locale.ROOT);
        if(op.equals("amount")&&a.length>=3){int v=intVal(a[2]);if(v<1)return true;settings.setPartyThreshold(v);s.sendMessage(Text.party("Ziel wurde auf §e"+v+" Votes §7gesetzt."));return true;}
        if(op.equals("status")){s.sendMessage(Text.party("Fortschritt: §e"+db.partyVotes()+" §8/ §6"+settings.partyThreshold()+" §7• Noch §e"+Math.max(0,settings.partyThreshold()-db.partyVotes())));return true;}
        if(op.equals("reset")){if(a.length>=3&&a[2].equalsIgnoreCase("confirm")&&confirmed(s,resetConfirm)){db.resetParty();s.sendMessage(Text.party("Zähler wurde auf 0 gesetzt."));return true;}mark(s,resetConfirm);s.sendMessage(Text.party("§cReset bestätigen: §d/voteadmin party reset confirm"));return true;}
        if(op.equals("location")){if(a.length>=3&&a[2].equalsIgnoreCase("set")&&s instanceof Player p){settings.setPartyLocation(p.getLocation());s.sendMessage(Text.party("Animationspunkt wurde gesetzt."));}else{var l=settings.partyLocation();s.sendMessage(Text.party(l==null?"§cKein eigener Party-Punkt gesetzt (Vote-Kiste wird genutzt).":"Animationspunkt: §e"+l.getWorld().getName()+" "+l.getBlockX()+" "+l.getBlockY()+" "+l.getBlockZ()));}return true;}
        if(op.equals("animation")){gui.playPartyAnimation();s.sendMessage(Text.party("Testanimation gestartet."));return true;}
        if(op.equals("reward")){if(s instanceof Player p)gui.openEditor(p,GuiManager.GuiType.EDIT_PARTY,0);else s.sendMessage(Text.party("§cItem-Editor nur ingame."));return true;}
        if(op.equals("money")&&a.length>=3){long v=longVal(a[2]);settings.setBundleMoney("party",v);s.sendMessage(Text.party("Guthaben pro Spieler: §e"+v+"$"));return true;}
        if((op.equals("key")||op.equals("keys"))&&a.length>=3){int v=intVal(a[2]);settings.setBundleKeys("party",v);s.sendMessage(Text.party("Vote-Keys pro Spieler: §e"+v));return true;}
        if(op.equals("pack"))return bundlePack(s,a,"party",2);
        if(op.equals("broadcast")&&a.length>=3){boolean v=on(a[2]);settings.setPartyBroadcast(v);s.sendMessage(Text.party("Broadcast ist jetzt "+onOff(v)+"§7."));return true;}
        if(op.equals("milestone")&&a.length>=3){String x=a[2].toLowerCase(Locale.ROOT);if(x.equals("list")){s.sendMessage(Text.party("Meilensteine: §e"+settings.partyMilestones()));return true;}if(a.length>=4){int v=intVal(a[3]);if(x.equals("add"))settings.addPartyMilestone(v);else if(x.equals("remove"))settings.removePartyMilestone(v);s.sendMessage(Text.party("Meilensteine: §e"+settings.partyMilestones()));return true;}}partyHelp(s);return true;
    }

    private boolean broadcast(CommandSender s,String[] a){if(a.length<2){s.sendMessage(Text.vote("Broadcast: "+onOff(settings.voteBroadcast())));return true;}boolean v=on(a[1]);settings.setVoteBroadcast(v);s.sendMessage(Text.vote("Vote-Broadcast ist jetzt "+onOff(v)+"§7."));return true;}

    private boolean streak(CommandSender s,String[] a){
        if(a.length<2){s.sendMessage(Text.vote("Streak: "+onOff(settings.streakEnabled())+" §8• §7Meilensteine: §e"+settings.streakMilestones()));return true;}String op=a[1].toLowerCase(Locale.ROOT);
        if(op.equals("on")||op.equals("off")){boolean v=op.equals("on");settings.setStreakEnabled(v);s.sendMessage(Text.vote("Vote-Streak ist jetzt "+onOff(v)+"§7."));return true;}
        if(op.equals("status")){s.sendMessage(Text.vote("Streak: "+onOff(settings.streakEnabled())+" §8• §7Meilensteine: §e"+settings.streakMilestones()));return true;}
        if(op.equals("milestone")&&a.length>=3){String x=a[2].toLowerCase(Locale.ROOT);if(x.equals("list")){s.sendMessage(Text.vote("Streak-Meilensteine: §e"+settings.streakMilestones()));return true;}if(a.length>=4){int d=intVal(a[3]);if(x.equals("add"))settings.addStreakMilestone(d);else if(x.equals("remove"))settings.removeStreakMilestone(d);s.sendMessage(Text.vote("Streak-Meilensteine: §e"+settings.streakMilestones()));return true;}}
        if(op.equals("reward")){
            if(a.length==3){int d=intVal(a[2]);if(s instanceof Player p)gui.openEditor(p,GuiManager.GuiType.EDIT_STREAK,d);else s.sendMessage(Text.vote("§cItem-Editor nur ingame."));return true;}
            if(a.length>=5&&a[2].equalsIgnoreCase("money")){int d=intVal(a[3]);long v=longVal(a[4]);settings.setBundleMoney("streak.rewards."+d,v);s.sendMessage(Text.vote("Streak-Guthaben gespeichert."));return true;}
            if(a.length>=5&&(a[2].equalsIgnoreCase("key")||a[2].equalsIgnoreCase("keys"))){int d=intVal(a[3]);int v=intVal(a[4]);settings.setBundleKeys("streak.rewards."+d,v);s.sendMessage(Text.vote("Streak-Keys gespeichert."));return true;}
            if(a.length>=7&&a[2].equalsIgnoreCase("pack")&&a[3].equalsIgnoreCase("add")){int d=intVal(a[4]);String pack=a[5];int v=intVal(a[6]);settings.setBundlePack("streak.rewards."+d,pack,v);s.sendMessage(Text.vote("Streak-Pack gespeichert."));return true;}
        }
        s.sendMessage(Text.vote("§cVerwendung: /voteadmin streak <on|off|status|milestone|reward>"));return true;
    }

    private boolean test(CommandSender s,String[] a){if(a.length>=3&&a[1].equalsIgnoreCase("vote")){Player p=Bukkit.getPlayerExact(a[2]);if(p==null){s.sendMessage(Text.vote("§cSpieler nicht online."));return true;}service.processTestVote(p);s.sendMessage(Text.vote("Test-Vote für §e"+p.getName()+" §7ausgeführt."));return true;}if(a.length>=2&&a[1].equalsIgnoreCase("party")){service.triggerParty(true);s.sendMessage(Text.party("Test-Voteparty ausgelöst (Zähler unverändert)."));return true;}s.sendMessage(Text.vote("§c/test: /voteadmin test vote <Spieler> | /voteadmin test party"));return true;}
    private boolean reload(CommandSender s){settings.load();service.integrations().refresh();gui.refreshHologram();s.sendMessage(Text.vote("VoteSystem-Einstellungen wurden neu geladen."));return true;}

    private boolean bundlePack(CommandSender s,String[] a,String root,int opIndex){if(a.length<=opIndex){s.sendMessage(Text.vote("§cPack: add <Pack> <Anzahl> | remove <Pack> | list"));return true;}String op=a[opIndex].toLowerCase(Locale.ROOT);if(op.equals("list")){s.sendMessage(Text.vote("Packs: §e"+settings.bundlePacks(root)));return true;}if(op.equals("add")&&a.length>opIndex+2){String pack=a[opIndex+1];int amount=intVal(a[opIndex+2]);if(amount<1||!service.integrations().packExists(pack)){s.sendMessage(Text.vote("§cPack nicht gefunden oder Anzahl ungültig."));return true;}settings.setBundlePack(root,pack,amount);s.sendMessage(Text.vote("Pack §e"+pack+" §7x§e"+amount+" §7gespeichert."));return true;}if(op.equals("remove")&&a.length>opIndex+1){settings.setBundlePack(root,a[opIndex+1],0);s.sendMessage(Text.vote("Pack entfernt."));return true;}return true;}

    private void help(CommandSender s){String line="§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━";s.sendMessage(line);s.sendMessage("§6§l✦ VOTE §8• §fBefehlsübersicht §6§l✦");s.sendMessage(line);s.sendMessage("§d/voteadmin status");s.sendMessage("§d/voteadmin site §b<add|remove|list|url|name|service|enable>");s.sendMessage("§d/voteadmin votereward §7[money|key|pack]");s.sendMessage("§d/voteadmin key give §b<Spieler> <Anzahl>");s.sendMessage("§d/voteadmin key giveall §b<Anzahl>");s.sendMessage("§d/voteadmin crate §b<set|remove|location|preview>");s.sendMessage("§d/voteadmin reward §b<add|remove|list|chance|amount|rarity|enable|clone|clear>");s.sendMessage("§d/voteadmin reward pack add §b<ID> <Pack> <Anzahl>");s.sendMessage("§d/voteadmin reward money add §b<ID> <Betrag>");s.sendMessage("§d/voteadmin reward key add §b<ID> <Anzahl>");s.sendMessage("§d/voteadmin party §b<amount|status|reset|reward|money|keys|pack|location|animation|milestone|broadcast>");s.sendMessage("§d/voteadmin streak §b<on|off|status|milestone|reward>");s.sendMessage("§d/voteadmin broadcast §b<on|off>");s.sendMessage("§d/voteadmin test §b<vote|party>");s.sendMessage("§d/voteadmin reload");s.sendMessage(line);}
    private void rewardHelp(CommandSender s){s.sendMessage(Text.vote("Reward: add/remove/list/chance/amount/rarity/enable/clone/clear | pack add | money add | key add"));}
    private void partyHelp(CommandSender s){s.sendMessage(Text.party("Admin: amount/status/reset/reward/money/keys/pack/location/animation/milestone/broadcast"));}

    private String onOff(boolean v){return v?"§aan":"§caus";}private boolean on(String s){return s.equalsIgnoreCase("on")||s.equalsIgnoreCase("an")||s.equalsIgnoreCase("true");}
    private int intVal(String s){try{return Math.max(0,Integer.parseInt(s));}catch(Exception e){return 0;}}private long longVal(String s){try{return Math.max(0L,Long.parseLong(s.replace(".","")));}catch(Exception e){return 0;}}private double doubleVal(String s){try{return Math.max(0.0001,Double.parseDouble(s.replace(',','.')));}catch(Exception e){return 1.0;}}
    private String safeId(String s){if(s==null||!s.matches("[A-Za-z0-9_-]{1,32}"))return null;return s.toLowerCase(Locale.ROOT);}private boolean url(String s){return s!=null&&(s.startsWith("https://")||s.startsWith("http://"));}
    private void mark(CommandSender s,Map<UUID,Long> map){if(s instanceof Player p)map.put(p.getUniqueId(),System.currentTimeMillis()+15000L);}private boolean confirmed(CommandSender s,Map<UUID,Long> map){if(!(s instanceof Player p))return true;Long t=map.remove(p.getUniqueId());return t!=null&&t>=System.currentTimeMillis();}

    @Override public List<String> onTabComplete(CommandSender s,Command c,String alias,String[] a){if(!s.hasPermission("nightpvp.vote.admin"))return List.of();if(a.length==1)return filter(List.of("status","site","votereward","key","crate","reward","party","broadcast","streak","test","reload"),a[0]);if(a.length==2){return switch(a[0].toLowerCase(Locale.ROOT)){case "site"->filter(List.of("add","remove","list","url","name","service","enable"),a[1]);case "votereward"->filter(List.of("money","key","pack"),a[1]);case "key"->filter(List.of("give","giveall"),a[1]);case "crate"->filter(List.of("set","remove","location","preview"),a[1]);case "reward"->filter(List.of("add","remove","list","chance","amount","rarity","enable","clone","clear","pack","money","key"),a[1]);case "party"->filter(List.of("amount","status","reset","reward","money","keys","pack","location","animation","milestone","broadcast"),a[1]);case "broadcast"->filter(List.of("on","off"),a[1]);case "streak"->filter(List.of("on","off","status","milestone","reward"),a[1]);case "test"->filter(List.of("vote","party"),a[1]);default->List.of();};}
        if(a.length==3&&a[0].equalsIgnoreCase("site")&&!a[1].equalsIgnoreCase("add"))return filter(settings.sites().stream().map(VoteSite::id).toList(),a[2]);if(a.length==3&&a[0].equalsIgnoreCase("reward")&&List.of("remove","chance","amount","rarity","enable","clone").contains(a[1].toLowerCase(Locale.ROOT)))return filter(settings.crateRewards().stream().map(RewardDefinition::id).toList(),a[2]);if(a.length==3&&a[0].equalsIgnoreCase("test")&&a[1].equalsIgnoreCase("vote"))return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(),a[2]);if(a.length==4&&a[0].equalsIgnoreCase("reward")&&a[1].equalsIgnoreCase("rarity"))return filter(List.of("gewoehnlich","selten","sehrselten","legendaer"),a[3]);if(a.length==4&&a[0].equalsIgnoreCase("reward")&&a[1].equalsIgnoreCase("enable"))return filter(List.of("on","off"),a[3]);if(a.length==5&&a[0].equalsIgnoreCase("reward")&&a[1].equalsIgnoreCase("pack")&&a[2].equalsIgnoreCase("add"))return filter(new ArrayList<>(service.integrations().packIds()),a[4]);return List.of();}
    private List<String> filter(Collection<String> values,String raw){String p=raw.toLowerCase(Locale.ROOT);return values.stream().filter(Objects::nonNull).filter(v->v.toLowerCase(Locale.ROOT).startsWith(p)).sorted(String.CASE_INSENSITIVE_ORDER).toList();}
}
