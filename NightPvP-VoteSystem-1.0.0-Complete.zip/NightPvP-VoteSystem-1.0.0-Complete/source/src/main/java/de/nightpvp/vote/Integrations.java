package de.nightpvp.vote;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

public final class Integrations {
    private final NightPvPVotePlugin plugin;
    private Class<?> moneyApi;
    private Method moneyReady;
    private Method moneyAdd;
    private Object packService;
    private Method packExists;
    private Method packAdd;
    private Method packIds;

    public Integrations(NightPvPVotePlugin plugin) { this.plugin=plugin; refresh(); }

    public void refresh() {
        moneyApi=null;moneyReady=null;moneyAdd=null;packService=null;packExists=null;packAdd=null;packIds=null;
        try {
            Plugin gp=Bukkit.getPluginManager().getPlugin("NightPvP-Guthaben");
            if(gp!=null&&gp.isEnabled()){moneyApi=Class.forName("de.nightpvp.guthaben.api.NightPvPGuthabenAPI",true,gp.getClass().getClassLoader());moneyReady=moneyApi.getMethod("isReady");moneyAdd=moneyApi.getMethod("addBalance", UUID.class,long.class,String.class);}
        } catch (Throwable ignored) {}
        try {
            Plugin p=Bukkit.getPluginManager().getPlugin("NightPvP-PackSystem");
            if(p!=null&&p.isEnabled()){
                Field f=p.getClass().getDeclaredField("packs");f.setAccessible(true);packService=f.get(p);
                if(packService!=null){Class<?> c=packService.getClass();packExists=c.getMethod("exists",String.class);packAdd=c.getMethod("add",Player.class,String.class,int.class);packIds=c.getMethod("ids");}
            }
        } catch (Throwable t) { plugin.getLogger().fine("PackSystem-API noch nicht verfügbar: "+t.getClass().getSimpleName()); }
    }

    public boolean moneyReady(){try{return moneyApi!=null&&Boolean.TRUE.equals(moneyReady.invoke(null));}catch(Throwable t){return false;}}
    public boolean addMoney(UUID uuid,long amount,String source){if(amount<=0)return true;try{return moneyReady()&&Boolean.TRUE.equals(moneyAdd.invoke(null,uuid,amount,source));}catch(Throwable t){plugin.getLogger().warning("Guthaben-Reward fehlgeschlagen: "+t.getMessage());return false;}}
    public boolean packReady(){return packService!=null;}
    public boolean packExists(String id){try{return packService!=null&&Boolean.TRUE.equals(packExists.invoke(packService,id));}catch(Throwable t){return false;}}
    public boolean addPack(Player player,String id,int amount){if(amount<=0)return true;try{if(!packExists(id))return false;packAdd.invoke(packService,player,id,amount);return true;}catch(Throwable t){plugin.getLogger().warning("Pack-Reward fehlgeschlagen: "+t.getMessage());return false;}}
    @SuppressWarnings("unchecked") public Set<String> packIds(){try{Object o=packIds==null?null:packIds.invoke(packService);if(o instanceof Set<?> s){Set<String>out=new TreeSet<>(String.CASE_INSENSITIVE_ORDER);for(Object x:s)out.add(String.valueOf(x));return out;}}catch(Throwable ignored){}return Set.of();}
}
