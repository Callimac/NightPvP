package de.nightpvp.vote;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.EventExecutor;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;

public final class NightPvPVotePlugin extends JavaPlugin {
    private SettingsStore settings;
    private VoteDatabase database;
    private Integrations integrations;
    private VoteService voteService;
    private GuiManager guiManager;

    @Override public void onEnable() {
        settings=new SettingsStore(this);settings.load();
        database=new VoteDatabase(this);
        try { database.open(); }
        catch (Exception e) {
            getLogger().severe("SQLite konnte nicht initialisiert werden: "+e.getMessage());
            getLogger().severe("NightPvP-VoteSystem wird deaktiviert, damit keine Votes verloren gehen.");
            getServer().getPluginManager().disablePlugin(this);return;
        }
        integrations=new Integrations(this);
        voteService=new VoteService(this,settings,database,integrations);
        guiManager=new GuiManager(this,settings,voteService);

        VoteCommand vote=new VoteCommand(guiManager);PluginCommand vc=getCommand("vote");if(vc!=null){vc.setExecutor(vote);vc.setTabCompleter(vote);}
        VoteAdminCommand admin=new VoteAdminCommand(this,settings,voteService,guiManager,database);PluginCommand ac=getCommand("voteadmin");if(ac!=null){ac.setExecutor(admin);ac.setTabCompleter(admin);}
        getServer().getPluginManager().registerEvents(new VoteListener(this,voteService,guiManager,settings),this);
        registerNuVotifierHook();
        getServer().getScheduler().runTaskLater(this,guiManager::refreshHologram,20L);
        getLogger().info("NightPvP VoteSystem 1.0.0 aktiviert: Vote-Key, Vote-Kiste, Roulette, VoteParty, Streak, SQLite.");
    }

    @Override public void onDisable() {
        if(guiManager!=null)guiManager.shutdown();
        if(database!=null)database.close();
    }

    @SuppressWarnings("unchecked")
    private void registerNuVotifierHook() {
        try {
            Plugin votifier=Bukkit.getPluginManager().getPlugin("Votifier");
            if(votifier==null||!votifier.isEnabled()){getLogger().warning("NuVotifier/Votifier ist nicht aktiv. Echte Webseiten-Votes werden erst verarbeitet, wenn Votifier installiert ist.");return;}
            Class<?> raw=Class.forName("com.vexsoftware.votifier.model.VotifierEvent",true,votifier.getClass().getClassLoader());
            if(!Event.class.isAssignableFrom(raw)){getLogger().severe("Gefundener VotifierEvent ist kein Bukkit-Event.");return;}
            Class<? extends Event> eventClass=(Class<? extends Event>)raw;
            Listener marker=new Listener(){};
            EventExecutor executor=(listener,event)->{
                try {
                    Object vote=event.getClass().getMethod("getVote").invoke(event);
                    String username=stringMethod(vote,"getUsername");
                    String service=stringMethod(vote,"getServiceName");
                    String time=stringMethod(vote,"getTimeStamp");
                    if(time.isBlank())time=stringMethod(vote,"getTimestamp");
                    String address=stringMethod(vote,"getAddress");
                    final String fTime=time;
                    Runnable work=()->voteService.processExternalVote(username,service,fTime,address);
                    if(event.isAsynchronous())getServer().getScheduler().runTask(this,work);else work.run();
                } catch (Throwable t) { getLogger().severe("NuVotifier-Vote konnte nicht verarbeitet werden: "+t.getMessage()); }
            };
            getServer().getPluginManager().registerEvent(eventClass,marker,EventPriority.HIGHEST,executor,this,true);
            getLogger().info("NuVotifier-Hook aktiv: VotifierEvent wird verarbeitet.");
        } catch (Throwable t) { getLogger().warning("NuVotifier-Hook konnte nicht registriert werden: "+t.getClass().getSimpleName()+": "+t.getMessage()); }
    }

    private String stringMethod(Object target,String name){try{Method m=target.getClass().getMethod(name);Object o=m.invoke(target);return o==null?"":String.valueOf(o);}catch(Throwable ignored){return "";}}

    public GuiManager getGuiManager(){return guiManager;}
}
