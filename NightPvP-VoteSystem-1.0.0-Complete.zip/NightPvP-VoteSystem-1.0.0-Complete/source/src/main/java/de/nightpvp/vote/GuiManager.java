package de.nightpvp.vote;

import org.bukkit.*;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class GuiManager {
    public enum GuiType { VOTE, PREVIEW, ROULETTE, EDIT_NORMAL, EDIT_PARTY, EDIT_STREAK }

    private final NightPvPVotePlugin plugin;
    private final SettingsStore settings;
    private final VoteService service;
    private final Map<UUID,GuiType> guiTypes=new HashMap<>();
    private final Map<UUID,Map<Integer,String>> voteSiteSlots=new HashMap<>();
    private final Map<UUID,Integer> streakEditorDays=new HashMap<>();
    private final Set<UUID> spinning=ConcurrentHashMap.newKeySet();
    private final Map<UUID,Inventory> rouletteInventories=new ConcurrentHashMap<>();
    private final Random random=new Random();
    private final String holoTag="nightpvp_vote_hologram";

    public GuiManager(NightPvPVotePlugin plugin,SettingsStore settings,VoteService service){this.plugin=plugin;this.settings=settings;this.service=service;}

    public void openVote(Player p){
        Inventory inv=Bukkit.createInventory(null,27,"§6§lVOTE");fill(inv,black());
        for(int s:new int[]{0,8,18,26})inv.setItem(s,named(Material.NETHER_STAR,"§6§lNightPvP Vote",List.of("§7Vote für NightPvP und sichere dir Belohnungen.")));
        Map<Integer,String> slots=new HashMap<>();int[] siteSlots={9,10,11,12,13,14,15,16,17};int idx=0;
        for(VoteSite site:settings.sites()){
            if(!site.enabled()||idx>=siteSlots.length)continue;int slot=siteSlots[idx++];
            inv.setItem(slot,named(Material.PAPER,"§6§l"+site.name(),List.of("§7Klicke, um den Vote-Link","§7im Chat zu öffnen.","","§8Service: "+site.service())));slots.put(slot,site.id());
        }
        if(idx==0)inv.setItem(13,named(Material.BARRIER,"§cKeine Vote-Seite eingerichtet",List.of("§7Ein Admin kann Vote-Seiten mit","§d/voteadmin site add ... §7hinzufügen.")));
        inv.setItem(20,named(Material.BOOK,"§e§lDEINE VOTES",List.of("§7Gesamt: §e"+service.total(p.getUniqueId()))));
        inv.setItem(22,named(Material.NETHER_STAR,"§6§lVOTEPARTY",List.of("§7Fortschritt: §e"+service.partyVotes()+" §8/ §6"+settings.partyThreshold(),"§7Noch §e"+Math.max(0,settings.partyThreshold()-service.partyVotes())+" §7Votes.")));
        inv.setItem(24,named(Material.CLOCK,"§b§lVOTE-STREAK",List.of("§7Aktuelle Serie: §b"+service.streak(p.getUniqueId())+" Tage")));
        guiTypes.put(p.getUniqueId(),GuiType.VOTE);voteSiteSlots.put(p.getUniqueId(),slots);p.openInventory(inv);
    }

    public void openPreview(Player p){
        Inventory inv=Bukkit.createInventory(null,54,"§6§lVOTE-KISTE §8• §7Vorschau");
        for(int i=45;i<54;i++)inv.setItem(i,black());
        int slot=0;for(RewardDefinition r:settings.crateRewards()){if(!r.enabled()||slot>=45)continue;inv.setItem(slot++,r.icon());}
        inv.setItem(49,named(Material.OAK_DOOR,"§c§lSCHLIESSEN",List.of("§7Klicke zum Schließen.")));
        guiTypes.put(p.getUniqueId(),GuiType.PREVIEW);p.openInventory(inv);
    }

    public void openEditor(Player p,GuiType type,int streakDays){
        String title=switch(type){case EDIT_NORMAL->"§6§lVOTE §8• §7Vote-Belohnung";case EDIT_PARTY->"§6§lVOTEPARTY §8• §7Belohnung";case EDIT_STREAK->"§b§lSTREAK §8• §7"+streakDays+" Tage";default->"EDITOR";};
        Inventory inv=Bukkit.createInventory(null,54,title);List<ItemStack> items=switch(type){case EDIT_NORMAL->settings.normalItems();case EDIT_PARTY->settings.partyItems();case EDIT_STREAK->settings.streakItems(streakDays);default->List.of();};
        int s=0;for(ItemStack i:items)if(s<45)inv.setItem(s++,i.clone());
        for(int i=45;i<54;i++)inv.setItem(i,black());
        inv.setItem(48,named(Material.BOOK,"§e§lREWARD-EDITOR",List.of("§7Linksklick auf Slot: Item aus", "§7deiner Haupthand als Vorlage setzen.", "§7Rechtsklick: Reward entfernen.", "", "§8Dein echtes Item wird nicht verbraucht.")));
        inv.setItem(49,named(Material.OAK_DOOR,"§a§lSPEICHERN & SCHLIESSEN",List.of("§7Klicke zum Speichern.")));
        guiTypes.put(p.getUniqueId(),type);if(type==GuiType.EDIT_STREAK)streakEditorDays.put(p.getUniqueId(),streakDays);p.openInventory(inv);
    }

    public boolean handleClick(Player p,Inventory inv,int rawSlot,ItemStack current,boolean left,boolean right){
        GuiType t=guiTypes.get(p.getUniqueId());if(t==null)return false;
        if(t==GuiType.EDIT_NORMAL||t==GuiType.EDIT_PARTY||t==GuiType.EDIT_STREAK){
            if(rawSlot==49){plugin.getServer().getScheduler().runTaskLater(plugin,p::closeInventory,1L);return true;}
            if(rawSlot>=0&&rawSlot<45){
                if(right){inv.setItem(rawSlot,null);return true;}
                if(left){ItemStack held=p.getInventory().getItemInMainHand();if(held==null||held.getType()==Material.AIR){p.sendMessage(Text.vote("§cNimm zuerst das gewünschte Reward-Item in die Haupthand."));return true;}inv.setItem(rawSlot,held.clone());return true;}
            }
            return true;
        }
        if(t==GuiType.VOTE){String id=voteSiteSlots.getOrDefault(p.getUniqueId(),Map.of()).get(rawSlot);if(id!=null){VoteSite site=settings.site(id);if(site!=null){p.closeInventory();sendVoteLink(p,site);}}return true;}
        if(t==GuiType.PREVIEW){if(rawSlot==49)p.closeInventory();return true;}
        return t==GuiType.ROULETTE;
    }

    public void handleClose(Player p,Inventory inv){
        UUID u=p.getUniqueId();GuiType t=guiTypes.get(u);if(t==null)return;
        if(t==GuiType.ROULETTE&&spinning.contains(u)){plugin.getServer().getScheduler().runTaskLater(plugin,()->{if(p.isOnline()&&spinning.contains(u)){Inventory r=rouletteInventories.get(u);if(r!=null)p.openInventory(r);}},1L);return;}
        if(t==GuiType.EDIT_NORMAL){settings.saveNormalItems(editorContents(inv));p.sendMessage(Text.vote("Vote-Itembelohnungen wurden gespeichert."));}
        else if(t==GuiType.EDIT_PARTY){settings.savePartyItems(editorContents(inv));p.sendMessage(Text.party("Voteparty-Itembelohnungen wurden gespeichert."));}
        else if(t==GuiType.EDIT_STREAK){int d=streakEditorDays.getOrDefault(u,0);settings.saveStreakItems(d,editorContents(inv));p.sendMessage(Text.vote("Streak-Belohnungen für §e"+d+" Tage §7wurden gespeichert."));}
        guiTypes.remove(u);voteSiteSlots.remove(u);streakEditorDays.remove(u);rouletteInventories.remove(u);
    }

    public boolean startRoulette(Player p){
        List<RewardDefinition> pool=service.eligibleCrateRewards();if(pool.isEmpty()){p.sendMessage(Text.vote("§cEs sind aktuell keine verfügbaren Vote-Kisten-Gewinne eingerichtet."));return false;}
        Inventory inv=Bukkit.createInventory(null,27,"§6§lVOTE-KISTE");for(int i=0;i<9;i++)inv.setItem(i,black());for(int i=18;i<27;i++)inv.setItem(i,black());
        inv.setItem(4,named(Material.NETHER_STAR,"§6§l▼ GEWINN ▼",List.of("§7Der mittlere Slot entscheidet.")));inv.setItem(22,named(Material.NETHER_STAR,"§6§l▲ GEWINN ▲",List.of("§7Der mittlere Slot entscheidet.")));
        RewardDefinition[] lane=new RewardDefinition[9];for(int i=0;i<9;i++){lane[i]=service.randomReward(pool);inv.setItem(9+i,lane[i].icon());}
        UUID u=p.getUniqueId();spinning.add(u);rouletteInventories.put(u,inv);guiTypes.put(u,GuiType.ROULETTE);p.openInventory(inv);p.playSound(p.getLocation(),Sound.BLOCK_NOTE_BLOCK_HAT,1f,1.3f);
        spinStep(p,inv,pool,lane,0,42);return true;
    }

    private void spinStep(Player p,Inventory inv,List<RewardDefinition> pool,RewardDefinition[] lane,int step,int max){
        UUID u=p.getUniqueId();if(!spinning.contains(u))return;
        if(!p.isOnline()){cancelSpin(u,true);return;}
        if(step>=max){RewardDefinition winner=lane[4];spinning.remove(u);inv.setItem(13,winner.icon());p.playSound(p.getLocation(),Sound.ENTITY_PLAYER_LEVELUP,1f,1.15f);plugin.getServer().getScheduler().runTaskLater(plugin,()->{if(p.isOnline()){service.giveCrateReward(p,winner);if(guiTypes.get(u)==GuiType.ROULETTE)p.closeInventory();}},20L);return;}
        for(int i=0;i<8;i++)lane[i]=lane[i+1];lane[8]=service.randomReward(pool);for(int i=0;i<9;i++)inv.setItem(9+i,lane[i].icon());
        p.playSound(p.getLocation(),Sound.BLOCK_NOTE_BLOCK_HAT,0.5f,1.5f);
        long delay=step<18?1L:step<30?2L:step<38?4L:6L;plugin.getServer().getScheduler().runTaskLater(plugin,()->spinStep(p,inv,pool,lane,step+1,max),delay);
    }

    public boolean isSpinning(UUID u){return spinning.contains(u);}
    public GuiType guiType(UUID u){return guiTypes.get(u);}
    public boolean isProtectedGui(UUID u){GuiType t=guiTypes.get(u);return t==GuiType.VOTE||t==GuiType.PREVIEW||t==GuiType.ROULETTE;}
    public boolean isEditor(UUID u){GuiType t=guiTypes.get(u);return t==GuiType.EDIT_NORMAL||t==GuiType.EDIT_PARTY||t==GuiType.EDIT_STREAK;}
    public void cancelSpin(UUID u,boolean refund){if(spinning.remove(u)&&refund)service.queueKeys(u,1);rouletteInventories.remove(u);guiTypes.remove(u);}
    public void shutdown(){for(UUID u:new ArrayList<>(spinning))cancelSpin(u,true);removeHologram();}

    public void refreshHologram(){removeHologram();Location base=settings.crateLocation();if(base==null||base.getWorld()==null)return;World w=base.getWorld();String[] lines={"§6§lVOTE-KISTE","§7Öffne die Kiste mit einem","§6Vote-Key"};double[] ys={2.25,2.00,1.75};for(int i=0;i<lines.length;i++){Location l=base.clone().add(0.5,ys[i],0.5);Entity e=w.spawnEntity(l,EntityType.ARMOR_STAND);if(e instanceof ArmorStand a){a.setVisible(false);a.setGravity(false);a.setMarker(true);a.setSmall(true);a.setInvulnerable(true);a.setCustomName(lines[i]);a.setCustomNameVisible(true);a.addScoreboardTag(holoTag);}}}
    public void removeHologram(){Location base=settings.crateLocation();if(base==null||base.getWorld()==null)return;for(Entity e:base.getWorld().getNearbyEntities(base.clone().add(0.5,2,0.5),4,4,4))if(e.getScoreboardTags().contains(holoTag))e.remove();}

    public void playPartyAnimation(){Location base=settings.partyLocation();if(base==null)base=settings.crateLocation();if(base==null||base.getWorld()==null){plugin.getLogger().warning("Voteparty-Animation übersprungen: kein Party-/Kisten-Standort gesetzt.");return;}Location center=base.clone().add(0.5,1.2,0.5);World w=center.getWorld();List<ItemStack> visuals=settings.partyItems();if(visuals.isEmpty())visuals=List.of(new ItemStack(Material.DIAMOND),new ItemStack(Material.EMERALD),new ItemStack(Material.GOLD_INGOT),service.createVoteKey(1));final List<ItemStack> vis=visuals;
        for(int burst=0;burst<8;burst++){long d=burst*8L;plugin.getServer().getScheduler().runTaskLater(plugin,()->{w.playSound(center,Sound.ENTITY_EXPERIENCE_ORB_PICKUP,1f,1.1f);w.spawnParticle(Particle.END_ROD,center,25,0.8,0.8,0.8,0.08);for(int i=0;i<8;i++){ItemStack stack=vis.get(random.nextInt(vis.size())).clone();stack.setAmount(1);Item item=w.dropItem(center,stack);item.setPickupDelay(Integer.MAX_VALUE);item.setInvulnerable(true);item.setVelocity(new Vector((random.nextDouble()-0.5)*0.9,0.55+random.nextDouble()*0.45,(random.nextDouble()-0.5)*0.9));plugin.getServer().getScheduler().runTaskLater(plugin,item::remove,70L);}},d);}
        plugin.getServer().getScheduler().runTaskLater(plugin,()->{try{w.spawnEntity(center.clone().add(0,1,0),EntityType.FIREWORK_ROCKET);w.spawnEntity(center.clone().add(0.7,1,0.2),EntityType.FIREWORK_ROCKET);w.spawnEntity(center.clone().add(-0.7,1,-0.2),EntityType.FIREWORK_ROCKET);}catch(Throwable ignored){}w.playSound(center,Sound.ENTITY_PLAYER_LEVELUP,1.2f,0.9f);for(Player online:Bukkit.getOnlinePlayers())online.sendMessage(Text.party("§aDie Belohnungen wurden verteilt! §8• §7Nächste Voteparty: §60 / "+settings.partyThreshold()+" Votes"));},72L);
    }

    private List<ItemStack> editorContents(Inventory inv){List<ItemStack>out=new ArrayList<>();for(int slot=0;slot<45;slot++){ItemStack i=inv.getItem(slot);if(i!=null&&i.getType()!=Material.AIR)out.add(i.clone());}return out;}
    private void fill(Inventory inv,ItemStack item){for(int i=0;i<inv.getSize();i++)inv.setItem(i,item.clone());}
    private ItemStack black(){return named(Material.BLACK_STAINED_GLASS_PANE," ",List.of());}
    private ItemStack named(Material m,String name,List<String> lore){ItemStack i=new ItemStack(m);ItemMeta meta=i.getItemMeta();if(meta!=null){meta.setDisplayName(name);meta.setLore(lore);i.setItemMeta(meta);}return i;}

    private void sendVoteLink(Player p,VoteSite site){String text=Text.c("&6&lVOTE &8» &7Klicke hier, um auf &e"+site.name()+" &7zu voten: &6&l[ZUM VOTEN KLICKEN]");
        try{ClassLoader cl=p.getClass().getClassLoader();Class<?> base=Class.forName("net.md_5.bungee.api.chat.BaseComponent",true,cl);Class<?> textComponent=Class.forName("net.md_5.bungee.api.chat.TextComponent",true,cl);Class<?> clickClass=Class.forName("net.md_5.bungee.api.chat.ClickEvent",true,cl);Class<?> actionClass=Class.forName("net.md_5.bungee.api.chat.ClickEvent$Action",true,cl);Object comp=textComponent.getConstructor(String.class).newInstance(text);@SuppressWarnings({"rawtypes","unchecked"})Object action=Enum.valueOf((Class<? extends Enum>)actionClass,"OPEN_URL");Object click=clickClass.getConstructor(actionClass,String.class).newInstance(action,site.url());textComponent.getMethod("setClickEvent",clickClass).invoke(comp,click);Object array=java.lang.reflect.Array.newInstance(base,1);java.lang.reflect.Array.set(array,0,comp);Object spigot=p.getClass().getMethod("spigot").invoke(p);spigot.getClass().getMethod("sendMessage",array.getClass()).invoke(spigot,array);}catch(Throwable t){p.sendMessage(text);p.sendMessage("§6"+site.url());}
    }
}
