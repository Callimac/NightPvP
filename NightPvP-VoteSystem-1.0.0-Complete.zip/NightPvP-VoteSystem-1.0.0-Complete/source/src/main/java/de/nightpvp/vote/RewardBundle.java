package de.nightpvp.vote;

import org.bukkit.inventory.ItemStack;
import java.util.*;

public final class RewardBundle {
    public long money;
    public int keys;
    public final List<ItemStack> items = new ArrayList<>();
    public final Map<String,Integer> packs = new LinkedHashMap<>();

    public RewardBundle copy() {
        RewardBundle b = new RewardBundle(); b.money = money; b.keys = keys;
        for (ItemStack i : items) if (i != null) b.items.add(i.clone());
        b.packs.putAll(packs); return b;
    }
    public boolean empty() { return money <= 0 && keys <= 0 && items.isEmpty() && packs.isEmpty(); }
}
