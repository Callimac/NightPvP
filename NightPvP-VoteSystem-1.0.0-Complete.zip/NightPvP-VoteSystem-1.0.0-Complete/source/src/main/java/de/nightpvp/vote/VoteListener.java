package de.nightpvp.vote;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class VoteListener implements Listener {
    private final NightPvPVotePlugin plugin;
    private final VoteService service;
    private final GuiManager gui;
    private final SettingsStore settings;

    public VoteListener(NightPvPVotePlugin plugin,VoteService service,GuiManager gui,SettingsStore settings){this.plugin=plugin;this.service=service;this.gui=gui;this.settings=settings;}

    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onInteract(PlayerInteractEvent e){
        if(e.getHand()!=null&&e.getHand()!=EquipmentSlot.HAND)return;Block b=e.getClickedBlock();if(b==null||!isCrate(b.getLocation()))return;
        Action a=e.getAction();if(a!=Action.LEFT_CLICK_BLOCK&&a!=Action.RIGHT_CLICK_BLOCK)return;e.setCancelled(true);Player p=e.getPlayer();
        if(a==Action.LEFT_CLICK_BLOCK){gui.openPreview(p);return;}
        ItemStack item=e.getItem();if(!service.isVoteKey(item)){p.sendMessage(Text.vote("§cDu benötigst einen Vote-Key, um diese Kiste zu öffnen."));return;}
        if(gui.isSpinning(p.getUniqueId()))return;
        if(gui.startRoulette(p)){int n=item.getAmount();item.setAmount(Math.max(0,n-1));}
    }

    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onBreak(BlockBreakEvent e){if(isCrate(e.getBlock().getLocation())){e.setCancelled(true);e.getPlayer().sendMessage(Text.vote("§cDie Vote-Kiste kann nicht abgebaut werden."));}}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onBurn(BlockBurnEvent e){if(isCrate(e.getBlock().getLocation()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST)
    public void onBlockExplode(BlockExplodeEvent e){e.blockList().removeIf(b->isCrate(b.getLocation()));}
    @EventHandler(priority=EventPriority.HIGHEST)
    public void onEntityExplode(EntityExplodeEvent e){e.blockList().removeIf(b->isCrate(b.getLocation()));}

    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onMove(InventoryMoveItemEvent e){Location s=e.getSource().getLocation();Location d=e.getDestination().getLocation();if((s!=null&&isCrate(s))||(d!=null&&isCrate(d)))e.setCancelled(true);}

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e){if(!(e.getWhoClicked() instanceof Player p))return;if(gui.handleClick(p,e.getInventory(),e.getRawSlot(),e.getCurrentItem(),e.isLeftClick(),e.isRightClick()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent e){if(e.getWhoClicked() instanceof Player p&&gui.guiType(p.getUniqueId())!=null)e.setCancelled(true);}
    @EventHandler
    public void onClose(InventoryCloseEvent e){if(e.getPlayer() instanceof Player p)gui.handleClose(p,e.getInventory());}
    @EventHandler
    public void onJoin(PlayerJoinEvent e){plugin.getServer().getScheduler().runTaskLater(plugin,()->service.deliverPending(e.getPlayer()),20L);}
    @EventHandler
    public void onQuit(PlayerQuitEvent e){if(gui.isSpinning(e.getPlayer().getUniqueId()))gui.cancelSpin(e.getPlayer().getUniqueId(),true);}

    private boolean isCrate(Location l){Location c=settings.crateLocation();return c!=null&&l!=null&&c.getWorld()!=null&&l.getWorld()!=null&&c.getWorld().getName().equals(l.getWorld().getName())&&c.getBlockX()==l.getBlockX()&&c.getBlockY()==l.getBlockY()&&c.getBlockZ()==l.getBlockZ();}
}
