package de.nightpvp.vote;

import org.bukkit.*;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDate;
import java.util.*;

public final class VoteService {
    private final NightPvPVotePlugin plugin;
    private final SettingsStore settings;
    private final VoteDatabase db;
    private final Integrations integrations;
    private final NamespacedKey keyMarker;
    private final Random random=new Random();

    public VoteService(NightPvPVotePlugin plugin,SettingsStore settings,VoteDatabase db,Integrations integrations){
        this.plugin=plugin;this.settings=settings;this.db=db;this.integrations=integrations;this.keyMarker=new NamespacedKey(plugin,"vote_key");
    }

    public ItemStack createVoteKey(int amount){
        ItemStack item=new ItemStack(Material.TRIPWIRE_HOOK,Math.max(1,Math.min(64,amount)));ItemMeta meta=item.getItemMeta();
        if(meta!=null){meta.setDisplayName("§6§lVOTE-KEY");meta.setLore(List.of("§7Öffnet die §6Vote-Kiste§7.","","§8» §7NightPvP Vote-System"));meta.getPersistentDataContainer().set(keyMarker,PersistentDataType.STRING,"nightpvp_vote_key");
            try{meta.getClass().getMethod("setEnchantmentGlintOverride",Boolean.class).invoke(meta,Boolean.TRUE);}catch(Throwable ignored){}
            item.setItemMeta(meta);}
        return item;
    }
    public boolean isVoteKey(ItemStack item){if(item==null||item.getType()!=Material.TRIPWIRE_HOOK)return false;ItemMeta m=item.getItemMeta();return m!=null&&m.getPersistentDataContainer().has(keyMarker,PersistentDataType.STRING);}

    public void processExternalVote(String username,String service,String voteTime,String address){
        if(username==null||username.isBlank())return;String name=username.trim();String svc=(service==null||service.isBlank())?"Unknown":service.trim();String ts=(voteTime==null||voteTime.isBlank())?Long.toString(System.currentTimeMillis()/60000L):voteTime.trim();
        OfflinePlayer off=Bukkit.getOfflinePlayer(name);UUID uuid=off.getUniqueId();String unique=hash(svc.toLowerCase(Locale.ROOT)+"|"+name.toLowerCase(Locale.ROOT)+"|"+ts+"|"+(address==null?"":address));
        processVote(uuid,name,svc,ts,unique,false);
    }

    public void processTestVote(Player player){String ts=Long.toString(System.currentTimeMillis());processVote(player.getUniqueId(),player.getName(),"TEST",ts,"TEST-"+UUID.randomUUID(),true);}

    private void processVote(UUID uuid,String name,String service,String ts,String unique,boolean test){
        if(!db.registerVote(unique,uuid,name,service,ts)){plugin.getLogger().info("Doppelter Vote ignoriert: "+name+" / "+service);return;}
        db.incrementTotal(uuid,name);
        VoteDatabase.StreakUpdate streak=settings.streakEnabled()?db.updateStreak(uuid,name,LocalDate.now()):new VoteDatabase.StreakUpdate(db.streak(uuid),false);
        Player online=Bukkit.getPlayerExact(name);RewardBundle normal=settings.normalBundle();
        if(online!=null&&online.isOnline()){RewardBundle rest=deliver(online,normal,"VOTE");if(!rest.empty())db.addPending(uuid,rest);online.sendMessage(Text.vote("Vielen Dank für deinen Vote!"));if(streak.changedToday())online.sendMessage(Text.vote("Deine Vote-Serie beträgt jetzt §e"+streak.streak()+" Tage§7!"));}
        else db.addPending(uuid,normal);
        if(settings.voteBroadcast())broadcast(Text.c("&6&lVOTE &8» &e"+name+" &7hat für NightPvP gevotet!"));
        if(streak.changedToday()&&settings.streakMilestones().contains(streak.streak())){
            RewardBundle milestone=settings.streakBundle(streak.streak());if(!milestone.empty()){if(online!=null&&online.isOnline()){RewardBundle rest=deliver(online,milestone,"VOTE_STREAK_"+streak.streak());if(!rest.empty())db.addPending(uuid,rest);}else db.addPending(uuid,milestone);}
        }
        int party=db.incrementParty();int threshold=settings.partyThreshold();
        if(party>=threshold){triggerParty(false);} else if(settings.partyBroadcast()&&settings.partyMilestones().contains(party))broadcast(Text.party("§e"+party+" / "+threshold+" Votes §7erreicht!"));
        if(test)plugin.getLogger().info("Test-Vote verarbeitet für "+name);
    }

    public void deliverPending(Player player){
        List<VoteDatabase.Pending> list=db.pending(player.getUniqueId());if(list.isEmpty())return;int delivered=0;
        for(VoteDatabase.Pending p:list){RewardBundle b=BundleCodec.decode(p.payload());RewardBundle rest=deliver(player,b,"VOTE_PENDING");if(rest.empty()){db.deletePending(p.id());delivered++;}else{db.deletePending(p.id());db.addPending(player.getUniqueId(),rest);}}
        if(delivered>0)player.sendMessage(Text.vote("§a"+delivered+" ausstehende Vote-Belohnung(en) wurden ausgezahlt."));
    }

    public RewardBundle deliver(Player player,RewardBundle source,String reason){
        RewardBundle rest=new RewardBundle();
        if(source.money>0&&!integrations.addMoney(player.getUniqueId(),source.money,"NightPvP-VoteSystem:"+reason))rest.money=source.money;
        if(source.keys>0){int left=giveKeys(player,source.keys);rest.keys=left;}
        for(ItemStack item:source.items){if(item==null)continue;Map<Integer,ItemStack> left=player.getInventory().addItem(item.clone());for(ItemStack l:left.values())if(l!=null)rest.items.add(l.clone());}
        for(var e:source.packs.entrySet()){if(!integrations.addPack(player,e.getKey(),e.getValue()))rest.packs.put(e.getKey(),e.getValue());}
        return rest;
    }

    public int giveKeys(Player player,int amount){int left=Math.max(0,amount);while(left>0){int stack=Math.min(64,left);Map<Integer,ItemStack> rem=player.getInventory().addItem(createVoteKey(stack));int failed=rem.values().stream().filter(Objects::nonNull).mapToInt(ItemStack::getAmount).sum();left-=stack;if(failed>0){left+=failed;break;}}return left;}

    public void giveCrateReward(Player player,RewardDefinition reward){
        boolean ok=true;
        switch(reward.type()){
            case ITEM -> {ItemStack i=reward.item();if(i!=null){i.setAmount(Math.max(1,reward.amount()));Map<Integer,ItemStack>left=player.getInventory().addItem(i);for(ItemStack l:left.values())if(l!=null&&player.getWorld()!=null)player.getWorld().dropItem(player.getLocation(),l);}}
            case PACK -> ok=integrations.addPack(player,reward.pack(),reward.amount());
            case MONEY -> ok=integrations.addMoney(player.getUniqueId(),reward.money(),"NightPvP-VoteCrate:"+reward.id());
            case KEY -> {int left=giveKeys(player,reward.amount());if(left>0){for(int x=0;x<left;x++)player.getWorld().dropItem(player.getLocation(),createVoteKey(1));}}
        }
        if(!ok){giveKeys(player,1);player.sendMessage(Text.vote("§cDer Gewinn konnte wegen einer fehlenden Integration nicht ausgezahlt werden. Dein Vote-Key wurde zurückgegeben."));return;}
        player.sendMessage(Text.vote("Du hast aus der Vote-Kiste §e"+reward.displayName()+" §7gewonnen!"));
        effect(player,reward.rarity());
        if(reward.rarity()==Rarity.LEGENDAER&&settings.legendaryBroadcast())broadcast(Text.vote("§e"+player.getName()+" §7hat einen §6legendären Gewinn §7aus der Vote-Kiste erhalten!"));
    }

    private void effect(Player p,Rarity r){Location l=p.getLocation().clone().add(0,1,0);World w=p.getWorld();
        if(r.level()>=2){w.spawnParticle(Particle.END_ROD,l,18,0.5,0.8,0.5,0.03);p.playSound(p.getLocation(),Sound.ENTITY_EXPERIENCE_ORB_PICKUP,1f,1.1f);}
        if(r.level()>=3){w.spawnParticle(Particle.TOTEM_OF_UNDYING,l,35,0.7,1.0,0.7,0.08);p.playSound(p.getLocation(),Sound.ENTITY_PLAYER_LEVELUP,1f,1.0f);}
        if(r==Rarity.LEGENDAER){try{w.spawnEntity(l,EntityType.FIREWORK_ROCKET);}catch(Throwable ignored){}p.playSound(p.getLocation(),Sound.ENTITY_FIREWORK_ROCKET_LAUNCH,1f,1f);}
    }

    public List<RewardDefinition> eligibleCrateRewards(){List<RewardDefinition>out=new ArrayList<>();for(RewardDefinition r:settings.crateRewards()){if(!r.enabled())continue;if(r.type()==RewardDefinition.Type.PACK&&!integrations.packReady())continue;if(r.type()==RewardDefinition.Type.MONEY&&!integrations.moneyReady())continue;out.add(r);}return out;}
    public RewardDefinition randomReward(List<RewardDefinition> rewards){if(rewards.isEmpty())return null;double total=rewards.stream().mapToDouble(RewardDefinition::chance).sum();double x=random.nextDouble()*total;for(RewardDefinition r:rewards){x-=r.chance();if(x<=0)return r;}return rewards.get(rewards.size()-1);}

    public void triggerParty(boolean test){
        int threshold=settings.partyThreshold();if(settings.partyBroadcast()){broadcast(Text.party("§e"+threshold+" Votes wurden erreicht!"));broadcast(Text.party("Die Voteparty startet am Spawn!"));}
        RewardBundle bundle=settings.partyBundle();for(Player p:Bukkit.getOnlinePlayers()){RewardBundle rest=deliver(p,bundle,"VOTEPARTY");if(!rest.empty())db.addPending(p.getUniqueId(),rest);p.sendMessage(Text.party("§aDeine Voteparty-Belohnung wurde verteilt!"));}
        plugin.getGuiManager().playPartyAnimation();
        if(!test)db.resetParty();
    }

    public void queueKeys(UUID uuid,int amount){if(amount<=0)return;RewardBundle b=new RewardBundle();b.keys=amount;db.addPending(uuid,b);}
    public void queueBundle(UUID uuid,RewardBundle b){db.addPending(uuid,b);}

    public int total(UUID uuid){return db.total(uuid);}public int streak(UUID uuid){return db.streak(uuid);}public int partyVotes(){return db.partyVotes();}
    public SettingsStore settings(){return settings;}public Integrations integrations(){return integrations;}

    private void broadcast(String message){for(Player p:Bukkit.getOnlinePlayers())p.sendMessage(message);plugin.getLogger().info(message.replace('§','&'));}

    private String hash(String raw){try{byte[]d=MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();for(byte x:d)b.append(String.format("%02x",x));return b.toString();}catch(Exception e){return raw;}}
}
