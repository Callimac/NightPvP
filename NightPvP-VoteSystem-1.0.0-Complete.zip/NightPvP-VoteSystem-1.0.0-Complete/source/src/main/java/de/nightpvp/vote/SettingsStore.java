package de.nightpvp.vote;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class SettingsStore {
    private final NightPvPVotePlugin plugin;
    private final File file;
    private YamlConfiguration cfg;

    public SettingsStore(NightPvPVotePlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "settings.yml");
    }

    public void load() {
        if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
        cfg = YamlConfiguration.loadConfiguration(file);
        defaults();
        save();
    }

    private void defaults() {
        boolean firstSetup = !cfg.getBoolean("setup.initialized", false);
        setDefault("broadcast.vote", true);
        setDefault("broadcast.legendary", true);
        setDefault("party.broadcast", true);
        setDefault("party.threshold", 100);
        if (!cfg.contains("party.milestones")) cfg.set("party.milestones", List.of(25, 50, 75, 90, 99));
        setDefault("normal.money", 2500L);
        setDefault("normal.keys", 1);
        setDefault("party.money", 2500L);
        setDefault("party.keys", 1);
        setDefault("streak.enabled", true);
        if (!cfg.contains("streak.milestones")) cfg.set("streak.milestones", List.of(3, 7, 14, 30));
        if (firstSetup) {
            cfg.set("normal.items.0", new ItemStack(Material.DIAMOND, 3));
            cfg.set("normal.items.1", new ItemStack(Material.IRON_INGOT, 8));
            cfg.set("normal.items.2", new ItemStack(Material.EXPERIENCE_BOTTLE, 16));
            cfg.set("party.items.0", new ItemStack(Material.DIAMOND, 3));
        }
        if (firstSetup) {
            saveReward(new RewardDefinition("diamanten", RewardDefinition.Type.ITEM,
                    new ItemStack(Material.DIAMOND, 8), null, 0, 8, 50.0, Rarity.GEWOEHNLICH, true));
            saveReward(new RewardDefinition("emeralds", RewardDefinition.Type.ITEM,
                    new ItemStack(Material.EMERALD, 12), null, 0, 12, 30.0, Rarity.SELTEN, true));
            saveReward(new RewardDefinition("goldbloecke", RewardDefinition.Type.ITEM,
                    new ItemStack(Material.GOLD_BLOCK, 4), null, 0, 4, 15.0, Rarity.SEHR_SELTEN, true));
            saveReward(new RewardDefinition("votekeys", RewardDefinition.Type.KEY,
                    null, null, 0, 3, 5.0, Rarity.LEGENDAER, true));
        }
        cfg.set("setup.initialized", true);
    }

    private void setDefault(String path, Object value) { if (!cfg.contains(path)) cfg.set(path, value); }
    public void save() {
        try { cfg.save(file); }
        catch (IOException e) { plugin.getLogger().severe("settings.yml konnte nicht gespeichert werden: " + e.getMessage()); }
    }

    public boolean voteBroadcast() { return cfg.getBoolean("broadcast.vote", true); }
    public void setVoteBroadcast(boolean v) { cfg.set("broadcast.vote", v); save(); }
    public boolean legendaryBroadcast() { return cfg.getBoolean("broadcast.legendary", true); }
    public boolean partyBroadcast() { return cfg.getBoolean("party.broadcast", true); }
    public void setPartyBroadcast(boolean v) { cfg.set("party.broadcast", v); save(); }
    public int partyThreshold() { return Math.max(1, cfg.getInt("party.threshold", 100)); }
    public void setPartyThreshold(int v) { cfg.set("party.threshold", Math.max(1,v)); save(); }

    public List<Integer> partyMilestones() {
        List<Integer> out=new ArrayList<>();
        for(Object o:cfg.getList("party.milestones",new ArrayList<>())){if(o instanceof Number n&&n.intValue()>0)out.add(n.intValue());else try{int v=Integer.parseInt(String.valueOf(o));if(v>0)out.add(v);}catch(Exception ignored){}}
        out.sort(Integer::compareTo);return out;
    }
    public void addPartyMilestone(int v){List<Integer>l=partyMilestones();if(!l.contains(v))l.add(v);l.sort(Integer::compareTo);cfg.set("party.milestones",l);save();}
    public void removePartyMilestone(int v){List<Integer>l=partyMilestones();l.removeIf(x->x==v);cfg.set("party.milestones",l);save();}

    public boolean streakEnabled() { return cfg.getBoolean("streak.enabled", true); }
    public void setStreakEnabled(boolean v) { cfg.set("streak.enabled",v); save(); }

    public List<Integer> streakMilestones() {
        List<Integer> out = new ArrayList<>();
        for (Object o : cfg.getList("streak.milestones", new ArrayList<>())) {
            if (o instanceof Number n && n.intValue() > 0) out.add(n.intValue());
            else try { int v = Integer.parseInt(String.valueOf(o)); if (v > 0) out.add(v); } catch (Exception ignored) {}
        }
        out.sort(Integer::compareTo); return out;
    }
    public void addStreakMilestone(int days) { List<Integer> l=streakMilestones(); if(!l.contains(days)) l.add(days); l.sort(Integer::compareTo); cfg.set("streak.milestones",l); save(); }
    public void removeStreakMilestone(int days) { List<Integer> l=streakMilestones(); l.removeIf(v->v==days); cfg.set("streak.milestones",l); save(); }

    public RewardBundle normalBundle() { return loadBundle("normal"); }
    public RewardBundle partyBundle() { return loadBundle("party"); }
    public RewardBundle streakBundle(int days) { return loadBundle("streak.rewards." + days); }
    public void saveNormalItems(List<ItemStack> items) { saveItems("normal.items",items); }
    public void savePartyItems(List<ItemStack> items) { saveItems("party.items",items); }
    public void saveStreakItems(int days,List<ItemStack> items) { saveItems("streak.rewards."+days+".items",items); }
    public List<ItemStack> normalItems() { return loadItems("normal.items"); }
    public List<ItemStack> partyItems() { return loadItems("party.items"); }
    public List<ItemStack> streakItems(int days) { return loadItems("streak.rewards."+days+".items"); }

    private RewardBundle loadBundle(String root) {
        RewardBundle b = new RewardBundle();
        b.money = Math.max(0L, cfg.getLong(root+".money",0L));
        b.keys = Math.max(0, cfg.getInt(root+".keys",0));
        b.items.addAll(loadItems(root+".items"));
        ConfigurationSection ps = cfg.getConfigurationSection(root+".packs");
        if (ps != null) for (String id : ps.getKeys(false)) { int a=ps.getInt(id,0); if(a>0)b.packs.put(id,a); }
        return b;
    }
    public void setBundleMoney(String root,long amount){cfg.set(root+".money",Math.max(0,amount));save();}
    public void setBundleKeys(String root,int amount){cfg.set(root+".keys",Math.max(0,amount));save();}
    public void setBundlePack(String root,String pack,int amount){cfg.set(root+".packs."+pack, amount<=0?null:amount);save();}
    public Map<String,Integer> bundlePacks(String root){return loadBundle(root).packs;}

    private List<ItemStack> loadItems(String path) {
        List<ItemStack> out = new ArrayList<>();
        ConfigurationSection sec = cfg.getConfigurationSection(path);
        if (sec == null) return out;
        List<String> keys = new ArrayList<>(sec.getKeys(false));
        keys.sort(Comparator.comparingInt(k -> { try { return Integer.parseInt(k); } catch(Exception e){return 999999;} }));
        for (String key : keys) { ItemStack i=sec.getItemStack(key); if(i!=null && i.getType()!=Material.AIR) out.add(i.clone()); }
        return out;
    }
    private void saveItems(String path,List<ItemStack> items){cfg.set(path,null);int n=0;for(ItemStack i:items)if(i!=null&&i.getType()!=Material.AIR)cfg.set(path+"."+(n++),i.clone());save();}

    public List<VoteSite> sites() {
        List<VoteSite> out = new ArrayList<>();
        ConfigurationSection sec = cfg.getConfigurationSection("sites");
        if(sec==null)return out;
        for(String id:sec.getKeys(false)){
            String root="sites."+id;
            out.add(new VoteSite(id,cfg.getString(root+".name",id),cfg.getString(root+".url",""),cfg.getString(root+".service",id),cfg.getBoolean(root+".enabled",true)));
        }
        out.sort(Comparator.comparing(VoteSite::id,String.CASE_INSENSITIVE_ORDER)); return out;
    }
    public VoteSite site(String id){return sites().stream().filter(s->s.id().equalsIgnoreCase(id)).findFirst().orElse(null);}
    public void saveSite(VoteSite s){String r="sites."+s.id();cfg.set(r+".name",s.name());cfg.set(r+".url",s.url());cfg.set(r+".service",s.service());cfg.set(r+".enabled",s.enabled());save();}
    public void removeSite(String id){cfg.set("sites."+id,null);save();}

    public List<RewardDefinition> crateRewards(){
        List<RewardDefinition> out=new ArrayList<>(); ConfigurationSection sec=cfg.getConfigurationSection("crate.rewards"); if(sec==null)return out;
        for(String id:sec.getKeys(false)){
            String r="crate.rewards."+id; String t=cfg.getString(r+".type","ITEM"); RewardDefinition.Type type;
            try{type=RewardDefinition.Type.valueOf(t.toUpperCase(Locale.ROOT));}catch(Exception e){type=RewardDefinition.Type.ITEM;}
            ItemStack item=cfg.getItemStack(r+".item"); String pack=cfg.getString(r+".pack",""); long money=cfg.getLong(r+".money",0); int amount=Math.max(1,cfg.getInt(r+".amount",item==null?1:item.getAmount()));
            double chance=Math.max(0.0001,cfg.getDouble(r+".chance",1.0)); Rarity rarity=Rarity.parse(cfg.getString(r+".rarity","gewoehnlich")); boolean enabled=cfg.getBoolean(r+".enabled",true);
            out.add(new RewardDefinition(id,type,item,pack,money,amount,chance,rarity,enabled));
        }
        out.sort(Comparator.comparing(RewardDefinition::id,String.CASE_INSENSITIVE_ORDER));return out;
    }
    public RewardDefinition crateReward(String id){return crateRewards().stream().filter(r->r.id().equalsIgnoreCase(id)).findFirst().orElse(null);}
    public void saveReward(RewardDefinition d){
        String r="crate.rewards."+d.id();cfg.set(r+".type",d.type().name());cfg.set(r+".item",d.item());cfg.set(r+".pack",d.pack());cfg.set(r+".money",d.money());cfg.set(r+".amount",d.amount());cfg.set(r+".chance",d.chance());cfg.set(r+".rarity",d.rarity().name());cfg.set(r+".enabled",d.enabled());save();
    }
    public void removeReward(String id){cfg.set("crate.rewards."+id,null);save();}
    public void clearRewards(){cfg.set("crate.rewards",null);save();}

    public void setCrateLocation(Location l){cfg.set("crate.location",encode(l));save();}
    public Location crateLocation(){return decode(cfg.getString("crate.location",null));}
    public void clearCrateLocation(){cfg.set("crate.location",null);save();}
    public void setPartyLocation(Location l){cfg.set("party.location",encode(l));save();}
    public Location partyLocation(){return decode(cfg.getString("party.location",null));}

    private String encode(Location l){if(l==null||l.getWorld()==null)return null;return l.getWorld().getName()+";"+l.getX()+";"+l.getY()+";"+l.getZ()+";"+l.getYaw()+";"+l.getPitch();}
    private Location decode(String raw){if(raw==null||raw.isBlank())return null;try{String[]p=raw.split(";");World w=Bukkit.getWorld(p[0]);if(w==null)return null;return new Location(w,Double.parseDouble(p[1]),Double.parseDouble(p[2]),Double.parseDouble(p[3]),Float.parseFloat(p[4]),Float.parseFloat(p[5]));}catch(Exception e){return null;}}
}
