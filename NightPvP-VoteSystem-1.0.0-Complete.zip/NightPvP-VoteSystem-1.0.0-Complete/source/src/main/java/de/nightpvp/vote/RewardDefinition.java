package de.nightpvp.vote;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class RewardDefinition {
    public enum Type { ITEM, PACK, MONEY, KEY }

    private final String id;
    private final Type type;
    private final ItemStack item;
    private final String pack;
    private final long money;
    private final int amount;
    private final double chance;
    private final Rarity rarity;
    private final boolean enabled;

    public RewardDefinition(String id, Type type, ItemStack item, String pack, long money, int amount,
                            double chance, Rarity rarity, boolean enabled) {
        this.id = id; this.type = type; this.item = item == null ? null : item.clone(); this.pack = pack;
        this.money = money; this.amount = Math.max(1, amount); this.chance = Math.max(0.0001, chance);
        this.rarity = rarity == null ? Rarity.GEWOEHNLICH : rarity; this.enabled = enabled;
    }
    public String id() { return id; }
    public Type type() { return type; }
    public ItemStack item() { return item == null ? null : item.clone(); }
    public String pack() { return pack; }
    public long money() { return money; }
    public int amount() { return amount; }
    public double chance() { return chance; }
    public Rarity rarity() { return rarity; }
    public boolean enabled() { return enabled; }

    public RewardDefinition withChance(double v) { return new RewardDefinition(id,type,item,pack,money,amount,v,rarity,enabled); }
    public RewardDefinition withAmount(int v) { return new RewardDefinition(id,type,item,pack,money,v,chance,rarity,enabled); }
    public RewardDefinition withRarity(Rarity v) { return new RewardDefinition(id,type,item,pack,money,amount,chance,v,enabled); }
    public RewardDefinition withEnabled(boolean v) { return new RewardDefinition(id,type,item,pack,money,amount,chance,rarity,v); }
    public RewardDefinition copyAs(String newId) { return new RewardDefinition(newId,type,item,pack,money,amount,chance,rarity,enabled); }

    public ItemStack icon() {
        ItemStack out;
        switch (type) {
            case ITEM -> {
                out = item == null ? new ItemStack(Material.BARRIER) : item.clone();
                if (out.getAmount() != amount) out.setAmount(Math.min(64, Math.max(1, amount)));
            }
            case PACK -> out = new ItemStack(Material.CHEST);
            case MONEY -> out = new ItemStack(Material.GOLD_INGOT);
            case KEY -> out = new ItemStack(Material.TRIPWIRE_HOOK);
            default -> out = new ItemStack(Material.BARRIER);
        }
        ItemMeta meta = out.getItemMeta();
        if (meta != null) {
            String name = switch (type) {
                case ITEM -> meta.hasDisplayName() ? meta.getDisplayName() : "§f" + pretty(out.getType().name());
                case PACK -> "§5§l" + amount + "x " + pack;
                case MONEY -> "§6§l" + String.format("%,d", money).replace(',', '.') + "$";
                case KEY -> "§6§l" + amount + "x VOTE-KEY";
            };
            meta.setDisplayName(name);
            List<String> lore = new ArrayList<>();
            lore.add("§8━━━━━━━━━━━━━━━━");
            lore.add("§7Seltenheit: " + rarity.display());
            lore.add("§7Gewichtung: §e" + chance);
            lore.add("§8ID: " + id);
            meta.setLore(lore);
            out.setItemMeta(meta);
        }
        return out;
    }

    public String displayName() {
        return switch (type) {
            case ITEM -> {
                ItemStack i = item;
                if (i != null && i.getItemMeta() != null && i.getItemMeta().hasDisplayName()) yield i.getItemMeta().getDisplayName();
                yield i == null ? "Item" : pretty(i.getType().name());
            }
            case PACK -> amount + "x " + pack;
            case MONEY -> String.format("%,d", money).replace(',', '.') + "$";
            case KEY -> amount + "x Vote-Key";
        };
    }

    private static String pretty(String raw) {
        String[] parts = raw.toLowerCase().split("_");
        StringBuilder b = new StringBuilder();
        for (String p : parts) {
            if (!b.isEmpty()) b.append(' ');
            if (!p.isEmpty()) b.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
        }
        return b.toString();
    }
}
