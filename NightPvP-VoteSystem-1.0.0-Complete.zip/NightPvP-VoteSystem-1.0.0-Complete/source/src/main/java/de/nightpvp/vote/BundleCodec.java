package de.nightpvp.vote;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public final class BundleCodec {
    private BundleCodec() {}

    public static String encode(RewardBundle b) {
        YamlConfiguration y = new YamlConfiguration();
        y.set("money", b.money); y.set("keys", b.keys);
        int n=0; for(ItemStack i:b.items) if(i!=null&&i.getType()!=Material.AIR)y.set("items."+(n++),i.clone());
        for(var e:b.packs.entrySet()) y.set("packs."+e.getKey(),e.getValue());
        return y.saveToString();
    }

    public static RewardBundle decode(String raw) {
        RewardBundle b=new RewardBundle(); if(raw==null||raw.isBlank())return b;
        YamlConfiguration y=new YamlConfiguration();
        try { y.loadFromString(raw); } catch (InvalidConfigurationException e) { return b; }
        b.money=Math.max(0L,y.getLong("money",0)); b.keys=Math.max(0,y.getInt("keys",0));
        ConfigurationSection items=y.getConfigurationSection("items");
        if(items!=null){List<String>ks=new ArrayList<>(items.getKeys(false));ks.sort(Comparator.comparingInt(k->{try{return Integer.parseInt(k);}catch(Exception e){return 99999;}}));for(String k:ks){ItemStack i=items.getItemStack(k);if(i!=null&&i.getType()!=Material.AIR)b.items.add(i.clone());}}
        ConfigurationSection packs=y.getConfigurationSection("packs"); if(packs!=null)for(String p:packs.getKeys(false)){int a=packs.getInt(p,0);if(a>0)b.packs.put(p,a);}
        return b;
    }
}
