package de.nightpvp.vote;

public record VoteSite(String id, String name, String url, String service, boolean enabled) {}
