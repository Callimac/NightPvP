# NightPvP VoteSystem 1.0.0 – Befehle

## Spieler
- `/vote` – öffnet die Vote-GUI.

## Admin (`nightpvp.vote.admin`)
- `/voteadmin` – Clean-&-Premium-Übersicht.
- `/voteadmin status`

### Vote-Seiten
- `/voteadmin site add <ID> <Name> <URL>`
- `/voteadmin site remove <ID>`
- `/voteadmin site list`
- `/voteadmin site url <ID> <URL>`
- `/voteadmin site name <ID> <Name>`
- `/voteadmin site service <ID> <ServiceName>`
- `/voteadmin site enable <ID> <on|off>`

### Normale Vote-Belohnung
- `/voteadmin votereward` – Item-Template-GUI.
- `/voteadmin votereward money <Betrag>`
- `/voteadmin votereward key <Anzahl>`
- `/voteadmin votereward pack add <Pack> <Anzahl>`
- `/voteadmin votereward pack remove <Pack>`
- `/voteadmin votereward pack list`

### Vote-Keys
- `/voteadmin key give <Spieler> <Anzahl>`
- `/voteadmin key giveall <Anzahl>`

### Vote-Kiste
- `/voteadmin crate set` – auf eine normale CHEST schauen.
- `/voteadmin crate remove`
- `/voteadmin crate location`
- `/voteadmin crate preview`

### Vote-Kisten-Rewards / Roulette
- `/voteadmin reward add <ID>` – Item aus Haupthand.
- `/voteadmin reward pack add <ID> <Pack> <Anzahl>`
- `/voteadmin reward money add <ID> <Betrag>`
- `/voteadmin reward key add <ID> <Anzahl>`
- `/voteadmin reward remove <ID>`
- `/voteadmin reward list`
- `/voteadmin reward chance <ID> <Chance/Gewichtung>`
- `/voteadmin reward amount <ID> <Anzahl>`
- `/voteadmin reward rarity <ID> <gewoehnlich|selten|sehrselten|legendaer>`
- `/voteadmin reward enable <ID> <on|off>`
- `/voteadmin reward clone <ID> <Neue-ID>`
- `/voteadmin reward clear` + `/voteadmin reward clear confirm`

### VoteParty
- `/voteadmin party amount <Votes>`
- `/voteadmin party status`
- `/voteadmin party reset` + `/voteadmin party reset confirm`
- `/voteadmin party reward` – Item-Template-GUI.
- `/voteadmin party money <Betrag>`
- `/voteadmin party keys <Anzahl>`
- `/voteadmin party pack add <Pack> <Anzahl>`
- `/voteadmin party pack remove <Pack>`
- `/voteadmin party pack list`
- `/voteadmin party location set`
- `/voteadmin party location`
- `/voteadmin party animation`
- `/voteadmin party milestone add <Votes>`
- `/voteadmin party milestone remove <Votes>`
- `/voteadmin party milestone list`
- `/voteadmin party broadcast <on|off>`

### Vote-Streak
- `/voteadmin streak on|off`
- `/voteadmin streak status`
- `/voteadmin streak milestone add <Tage>`
- `/voteadmin streak milestone remove <Tage>`
- `/voteadmin streak milestone list`
- `/voteadmin streak reward <Tage>` – Item-Template-GUI.
- `/voteadmin streak reward money <Tage> <Betrag>`
- `/voteadmin streak reward key <Tage> <Anzahl>`
- `/voteadmin streak reward pack add <Tage> <Pack> <Anzahl>`

### Broadcast / Tests
- `/voteadmin broadcast <on|off>`
- `/voteadmin test vote <Spieler>`
- `/voteadmin test party`
- `/voteadmin reload`

## Reward-Editor-GUIs
Die Item-GUIs sind absichtlich als sichere Template-Editoren gebaut:
- Linksklick auf einen Reward-Slot: Kopie des Items aus der Haupthand setzen/ersetzen.
- Rechtsklick: Reward entfernen.
- Das echte Item in der Haupthand wird nicht verbraucht.
- Gespeicherte Reward-Items können nicht aus dem Editor herausgenommen/dupliziert werden.
