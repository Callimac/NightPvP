# NightPvP VoteSystem – Test-Checkliste

1. Vollständiger Serverneustart, kein /reload.
2. Konsole: VoteSystem startet ohne ClassNotFound/LinkageError; NuVotifier-Hook wird als aktiv gemeldet.
3. `/vote` öffnet 3x9 GUI. Seiten klicken -> klickbarer Link im Chat.
4. `/voteadmin key give <Name> 2`: Vote-Key ist TRIPWIRE_HOOK und stackbar.
5. Normale Stolperdrahthaken öffnen die Vote-Kiste NICHT.
6. `/voteadmin crate set` auf normaler CHEST: Hologramm erscheint.
7. Chest lässt sich nicht abbauen/wegsprengen/verbrennen; Hopper wird blockiert.
8. Linksklick Chest -> Preview.
9. Rechtsklick mit Vote-Key -> 9-Slot-Roulette; GUI kann während Spin nicht geschlossen werden; genau 1 Key wird verbraucht.
10. Mittlerer Slot gewinnt; Rarity-Effekt/Legendär-Feuerwerk testen.
11. `/voteadmin reward add test` mit Item in Hand; chance/amount/rarity/enable/clone testen.
12. `/voteadmin reward pack add <ID> <Pack> <Anzahl>` mit echtem PackSystem testen.
13. `/voteadmin votereward` Itemeditor + money/key/pack Einstellungen testen.
14. NuVotifier `/testvote <Name>` testen: Reward, 2.500$, Vote-Key, Broadcast, Party +1.
15. Gleichen externen Event-Datensatz erneut senden: keine Doppelbelohnung.
16. Offline-Vote testen: Spieler offline voten lassen, Join -> Pending Reward wird ausgezahlt.
17. Streak: Testdaten bzw. Tageswechsel prüfen; gleiche Tagesvotes erhöhen Streak nicht mehrfach.
18. `/voteadmin party amount 3`, drei Testvotes -> Party startet, alle Online-Spieler erhalten Reward, Zähler reset.
19. `/voteadmin party animation` -> dekorative Items nicht aufsammelbar, verschwinden, Feuerwerk am Ende.
20. `/voteadmin party pack add ...` und `/voteadmin votereward pack add ...` testen.
21. Serverneustart: Votes/Streak/Party/Pending/Kiste/Seiten/Rewards bleiben erhalten.
