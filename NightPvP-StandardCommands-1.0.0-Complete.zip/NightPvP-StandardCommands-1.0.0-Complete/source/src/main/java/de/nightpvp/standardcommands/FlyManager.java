package de.nightpvp.standardcommands;

import org.bukkit.entity.Player;

public final class FlyManager {
    private final StandardCommandsPlugin plugin;
    public FlyManager(StandardCommandsPlugin plugin) { this.plugin = plugin; }

    public boolean allowed(Player player) {
        return player.hasPermission("nightpvp.standardcommands.fly") || plugin.getRankBridge().atLeastPlayerRank(player, "SUPREME");
    }

    public void toggle(Player player) {
        if (!allowed(player)) { Text.send(player, "&b&lFLY &8» &cDu hast keine Berechtigung für den Flugmodus."); return; }
        boolean combatBypass = plugin.getRankBridge().isTeam(player) || player.hasPermission("nightpvp.standardcommands.fly.combat");
        if (!player.getAllowFlight() && plugin.getCombatManager().inCombat(player) && !combatBypass) {
            Text.send(player, "&b&lFLY &8» &cDu kannst den Flugmodus während eines Kampfes nicht aktivieren."); return;
        }
        boolean next = !player.getAllowFlight();
        player.setAllowFlight(next);
        if (!next) player.setFlying(false);
        Text.send(player, "&b&lFLY &8» &7Flugmodus wurde " + (next ? "&aaktiviert" : "&cdeaktiviert") + "&7.");
    }

    public void handleCombatStart(Player player) {
        if (!player.getAllowFlight()) return;
        if (plugin.getRankBridge().isTeam(player) || player.hasPermission("nightpvp.standardcommands.fly.combat")) return;
        player.setFlying(false);
        player.setAllowFlight(false);
        Text.send(player, "&b&lFLY &8» &cFlugmodus wurde deaktiviert, da du dich im Kampf befindest.");
    }

    public void reset(Player player) {
        if (player.getGameMode() == org.bukkit.GameMode.SURVIVAL || player.getGameMode() == org.bukkit.GameMode.ADVENTURE) {
            player.setFlying(false); player.setAllowFlight(false);
        }
    }
}
