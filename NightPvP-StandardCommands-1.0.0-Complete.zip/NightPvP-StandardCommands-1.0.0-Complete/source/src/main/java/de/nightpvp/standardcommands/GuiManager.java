package de.nightpvp.standardcommands;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

public final class GuiManager {
    public static final String HOME_TITLE = Text.c("&e&lHOME");
    public static final String HOME_DELETE_TITLE = Text.c("&e&lHOME &8• &cLöschen");
    public static final String WARP_TITLE = Text.c("&6&lWARP");
    public static final String TRASH_TITLE = Text.c("&c&lTRASH");
    private final StandardCommandsPlugin plugin;
    private final NamespacedKey homeKey;
    private final NamespacedKey warpKey;
    private final Map<UUID, Integer> homePages = new HashMap<>();
    private final Map<UUID, Integer> warpPages = new HashMap<>();
    private final Map<UUID, String> pendingDelete = new HashMap<>();
    private static final int[] CONTENT = {10,11,12,13,14,15,16,19,20,21,22,23,24,25};

    public GuiManager(StandardCommandsPlugin plugin) {
        this.plugin = plugin;
        homeKey = new NamespacedKey(plugin, "home_name");
        warpKey = new NamespacedKey(plugin, "warp_name");
    }

    public void openHome(Player p, int page) {
        int limit = plugin.homeLimit(p);
        Map<String, org.bukkit.Location> homes = plugin.getDataStore().getHomes(p.getUniqueId());
        int pages = Math.max(1, (Math.max(limit, homes.size()) + CONTENT.length - 1) / CONTENT.length);
        page = Math.max(0, Math.min(page, pages - 1));
        homePages.put(p.getUniqueId(), page);
        Inventory inv = Bukkit.createInventory(null, 54, HOME_TITLE);
        fill(inv);
        List<String> names = new ArrayList<>(homes.keySet());
        names.sort(String.CASE_INSENSITIVE_ORDER);
        int start = page * CONTENT.length;
        for (int i=0;i<CONTENT.length;i++) {
            int global = start + i;
            if (global < names.size()) {
                String name = names.get(global);
                org.bukkit.Location loc = homes.get(name);
                ItemStack bed = named(Material.YELLOW_BED, "&e&lHome: " + name,
                        "&7Welt: &f" + (loc.getWorld()==null?"?":loc.getWorld().getName()),
                        "&7X: &f" + loc.getBlockX() + " &7Y: &f" + loc.getBlockY() + " &7Z: &f" + loc.getBlockZ(),
                        "", "&eLinksklick &8» &7Teleportieren", "&cRechtsklick &8» &7Home löschen");
                ItemMeta meta = bed.getItemMeta(); meta.getPersistentDataContainer().set(homeKey, PersistentDataType.STRING, name); bed.setItemMeta(meta);
                inv.setItem(CONTENT[i], bed);
            } else if (global < limit) {
                inv.setItem(CONTENT[i], named(Material.GRAY_BED, "&7Freier Home-Slot", "&7Setze ein Home mit", "&e/sethome <Name>"));
            }
        }
        inv.setItem(49, named(Material.OAK_DOOR, "&cSchließen"));
        if (page > 0) inv.setItem(45, named(Material.ARROW, "&eVorherige Seite"));
        if (page + 1 < pages) inv.setItem(53, named(Material.ARROW, "&eNächste Seite"));
        p.openInventory(inv);
    }

    public void openHomeDelete(Player p, String name) {
        pendingDelete.put(p.getUniqueId(), name);
        Inventory inv = Bukkit.createInventory(null, 27, HOME_DELETE_TITLE); fill(inv);
        inv.setItem(11, named(Material.LIME_STAINED_GLASS_PANE, "&a&lBESTÄTIGEN", "&7Home &e" + name + " &7löschen."));
        inv.setItem(15, named(Material.RED_STAINED_GLASS_PANE, "&c&lABBRECHEN", "&7Home behalten."));
        p.openInventory(inv);
    }

    public void handleHomeClick(Player p, int slot, boolean right, ItemStack item) {
        if (slot == 49) { p.closeInventory(); return; }
        int page = homePages.getOrDefault(p.getUniqueId(), 0);
        if (slot == 45) { openHome(p, page-1); return; }
        if (slot == 53) { openHome(p, page+1); return; }
        if (item == null || !item.hasItemMeta()) return;
        String name = item.getItemMeta().getPersistentDataContainer().get(homeKey, PersistentDataType.STRING);
        if (name == null) return;
        if (right) { openHomeDelete(p, name); return; }
        plugin.teleportHome(p, name);
    }

    public void handleDeleteConfirm(Player p, int slot) {
        String name = pendingDelete.remove(p.getUniqueId());
        if (name == null) { p.closeInventory(); return; }
        if (slot == 11) {
            plugin.getDataStore().delHome(p.getUniqueId(), name);
            Text.send(p, "&e&lHOME &8» &7Das Home &e" + name + " &7wurde erfolgreich gelöscht.");
            openHome(p, homePages.getOrDefault(p.getUniqueId(), 0));
        } else if (slot == 15) openHome(p, homePages.getOrDefault(p.getUniqueId(), 0));
    }

    public void openWarp(Player p, int page) {
        Map<String, org.bukkit.Location> warps = plugin.getDataStore().getWarps();
        List<String> names = new ArrayList<>(warps.keySet()); names.sort(String.CASE_INSENSITIVE_ORDER);
        int pages = Math.max(1, (names.size()+CONTENT.length-1)/CONTENT.length);
        page = Math.max(0, Math.min(page,pages-1)); warpPages.put(p.getUniqueId(), page);
        Inventory inv = Bukkit.createInventory(null,54,WARP_TITLE); fill(inv);
        int start=page*CONTENT.length;
        for (int i=0;i<CONTENT.length && start+i<names.size();i++) {
            String name=names.get(start+i); ItemStack base=plugin.getDataStore().getWarpIcon(name);
            if (base==null || base.getType().isAir()) base=new ItemStack(Material.ENDER_PEARL);
            ItemStack icon=base.clone(); icon.setAmount(1); ItemMeta meta=icon.getItemMeta();
            meta.setDisplayName(Text.c("&6&l"+name));
            List<String> lore=new ArrayList<>(); lore.add(Text.c("&6Linksklick &8» &7Teleportieren")); meta.setLore(lore);
            meta.getPersistentDataContainer().set(warpKey,PersistentDataType.STRING,name); icon.setItemMeta(meta); inv.setItem(CONTENT[i],icon);
        }
        inv.setItem(49,named(Material.OAK_DOOR,"&cSchließen"));
        if(page>0)inv.setItem(45,named(Material.ARROW,"&6Vorherige Seite"));
        if(page+1<pages)inv.setItem(53,named(Material.ARROW,"&6Nächste Seite")); p.openInventory(inv);
    }

    public void handleWarpClick(Player p,int slot,ItemStack item){
        if(slot==49){p.closeInventory();return;} int page=warpPages.getOrDefault(p.getUniqueId(),0);
        if(slot==45){openWarp(p,page-1);return;} if(slot==53){openWarp(p,page+1);return;}
        if(item==null||!item.hasItemMeta())return; String name=item.getItemMeta().getPersistentDataContainer().get(warpKey,PersistentDataType.STRING);
        if(name!=null) plugin.teleportWarp(p,name);
    }

    public void openTrash(Player p){ Inventory inv=Bukkit.createInventory(null,54,TRASH_TITLE); p.openInventory(inv); Text.send(p,"&c&lTRASH &8» &7Der Mülleimer wurde geöffnet."); }

    public ItemStack named(Material m,String name,String... lore){
        ItemStack item=new ItemStack(m); ItemMeta meta=item.getItemMeta(); meta.setDisplayName(Text.c(name));
        if(lore.length>0) meta.setLore(Arrays.stream(lore).map(Text::c).toList()); meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES); item.setItemMeta(meta); return item;
    }
    private void fill(Inventory inv){ ItemStack glass=named(Material.BLACK_STAINED_GLASS_PANE," "); for(int i=0;i<inv.getSize();i++)inv.setItem(i,glass); }
}
