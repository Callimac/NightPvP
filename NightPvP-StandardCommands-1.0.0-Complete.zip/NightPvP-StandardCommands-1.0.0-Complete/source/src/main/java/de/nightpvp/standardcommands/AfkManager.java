package de.nightpvp.standardcommands;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;

public final class AfkManager {
    private final StandardCommandsPlugin plugin;
    private final Map<UUID, Long> lastActive = new HashMap<>();
    private final Set<UUID> afk = new HashSet<>();

    public AfkManager(StandardCommandsPlugin plugin) { this.plugin = plugin; }

    public void start() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            long threshold = Math.max(1, plugin.getConfig().getLong("afk.auto-minutes", 5)) * 60_000L;
            long now = System.currentTimeMillis();
            for (Player p : Bukkit.getOnlinePlayers()) {
                long last = lastActive.getOrDefault(p.getUniqueId(), now);
                if (!afk.contains(p.getUniqueId()) && now - last >= threshold && !plugin.getCombatManager().inCombat(p)) setAfk(p, true, true);
            }
        }, 20L * 20L, 20L * 20L);
    }

    public void markActive(Player player) {
        lastActive.put(player.getUniqueId(), System.currentTimeMillis());
        if (afk.remove(player.getUniqueId())) Text.send(player, "&6&lAFK &8» &7Du bist nicht mehr als &6AFK &7markiert.");
    }

    public void toggle(Player player) {
        if (!afk.contains(player.getUniqueId()) && plugin.getCombatManager().inCombat(player)) {
            Text.send(player, "&6&lAFK &8» &cDu kannst dich während eines Kampfes nicht als AFK markieren."); return;
        }
        setAfk(player, !afk.contains(player.getUniqueId()), false);
    }

    private void setAfk(Player player, boolean state, boolean automatic) {
        if (state) {
            afk.add(player.getUniqueId());
            Text.send(player, "&6&lAFK &8» &7Du bist jetzt als &6AFK &7markiert.");
        } else {
            afk.remove(player.getUniqueId());
            lastActive.put(player.getUniqueId(), System.currentTimeMillis());
            Text.send(player, "&6&lAFK &8» &7Du bist nicht mehr als &6AFK &7markiert.");
        }
    }

    public boolean isAfk(Player player) { return afk.contains(player.getUniqueId()); }
    public void join(Player player) { afk.remove(player.getUniqueId()); lastActive.put(player.getUniqueId(), System.currentTimeMillis()); }
    public void quit(Player player) { afk.remove(player.getUniqueId()); lastActive.remove(player.getUniqueId()); }
}
