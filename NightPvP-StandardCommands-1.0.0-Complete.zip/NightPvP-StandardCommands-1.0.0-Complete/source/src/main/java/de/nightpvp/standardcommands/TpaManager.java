package de.nightpvp.standardcommands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;

public final class TpaManager {
    public enum Type { TO_TARGET, TARGET_TO_SENDER }
    public record Request(UUID sender, UUID target, Type type, long expiresAt) {}
    private final StandardCommandsPlugin plugin;
    private final Map<UUID, List<Request>> incoming = new HashMap<>();

    public TpaManager(StandardCommandsPlugin plugin) { this.plugin = plugin; }

    public void send(Player sender, Player target, Type type) {
        if (sender.equals(target)) { Text.send(sender, "&d&lTPA &8» &cDu kannst dir nicht selbst eine Teleportanfrage senden."); return; }
        if (plugin.getCombatManager().inCombat(sender)) { Text.send(sender, "&d&lTPA &8» &cDu kannst während eines Kampfes keine Teleportanfrage senden."); return; }
        long remain = plugin.getCooldownManager().remaining(sender, "tpa", 10);
        if (remain > 0) { Text.send(sender, "&d&lTPA &8» &cBitte warte noch &d" + remain + " Sekunden&c."); return; }
        plugin.getCooldownManager().use(sender, "tpa", 10);
        Request r = new Request(sender.getUniqueId(), target.getUniqueId(), type, System.currentTimeMillis() + 60_000L);
        incoming.computeIfAbsent(target.getUniqueId(), x -> new ArrayList<>()).removeIf(old -> old.sender().equals(sender.getUniqueId()));
        incoming.computeIfAbsent(target.getUniqueId(), x -> new ArrayList<>()).add(r);
        if (type == Type.TO_TARGET) {
            Text.send(sender, "&d&lTPA &8» &7Du hast &d" + target.getName() + " &7eine Teleportanfrage gesendet.");
            Text.send(target, "&d&lTPA &8» &d" + sender.getName() + " &7möchte sich zu dir teleportieren.");
        } else {
            Text.send(sender, "&d&lTPA &8» &7Du hast &d" + target.getName() + " &7eine Teleportanfrage zu dir gesendet.");
            Text.send(target, "&d&lTPA &8» &d" + sender.getName() + " &7möchte, dass du dich zu ihm teleportierst.");
        }
        Component accept = Component.text("[ANNEHMEN]", NamedTextColor.GREEN, TextDecoration.BOLD);
        accept = accept.clickEvent(ClickEvent.runCommand("/tpaccept " + sender.getName()));
        Component deny = Component.text("[ABLEHNEN]", NamedTextColor.RED, TextDecoration.BOLD);
        deny = deny.clickEvent(ClickEvent.runCommand("/tpdeny " + sender.getName()));
        Component buttons = accept.append(Component.text(" • ", NamedTextColor.DARK_GRAY)).append(deny);
        target.sendMessage(buttons);
        Bukkit.getScheduler().runTaskLater(plugin, () -> expire(r), 20L * 60L);
    }

    private void expire(Request request) {
        List<Request> list = incoming.get(request.target());
        if (list == null || !list.remove(request)) return;
        Player s = Bukkit.getPlayer(request.sender());
        Player t = Bukkit.getPlayer(request.target());
        if (s != null) Text.send(s, "&d&lTPA &8» &cDeine Teleportanfrage ist abgelaufen.");
        if (t != null) Text.send(t, "&d&lTPA &8» &cDie Teleportanfrage ist abgelaufen.");
    }

    public void accept(Player target, String senderName) {
        Request r = find(target, senderName);
        if (r == null) { Text.send(target, "&d&lTPA &8» &cDu hast aktuell keine passende Teleportanfrage."); return; }
        if (plugin.getCombatManager().inCombat(target)) { Text.send(target, "&d&lTPA &8» &cDu kannst während eines Kampfes keine Teleportanfrage annehmen."); return; }
        Player sender = Bukkit.getPlayer(r.sender());
        if (sender == null) { remove(r); Text.send(target, "&d&lTPA &8» &cDieser Spieler ist nicht mehr online."); return; }
        if (plugin.getCombatManager().inCombat(sender)) { Text.send(target, "&d&lTPA &8» &cDie Anfrage kann nicht angenommen werden, da der andere Spieler im Kampf ist."); return; }
        remove(r);
        Text.send(target, "&d&lTPA &8» &7Du hast die Teleportanfrage von &d" + sender.getName() + " &7angenommen.");
        Text.send(sender, "&d&lTPA &8» &a" + target.getName() + " hat deine Teleportanfrage angenommen.");
        Player mover = r.type() == Type.TO_TARGET ? sender : target;
        Player destination = r.type() == Type.TO_TARGET ? target : sender;
        org.bukkit.Location destinationLocation = destination.getLocation().clone();
        plugin.getTeleportService().delayed(mover, destinationLocation, "TPA", "&d",
                "&d&lTPA &8» &7Du wurdest zu &d" + destination.getName() + " &7teleportiert.",
                () -> plugin.getTeleportService().isSafeExact(destinationLocation));
    }

    public void deny(Player target, String senderName) {
        Request r = find(target, senderName);
        if (r == null) { Text.send(target, "&d&lTPA &8» &cDu hast aktuell keine passende Teleportanfrage."); return; }
        remove(r);
        Player sender = Bukkit.getPlayer(r.sender());
        Text.send(target, "&d&lTPA &8» &7Du hast die Teleportanfrage abgelehnt.");
        if (sender != null) Text.send(sender, "&d&lTPA &8» &c" + target.getName() + " hat deine Teleportanfrage abgelehnt.");
    }

    private Request find(Player target, String senderName) {
        List<Request> list = incoming.get(target.getUniqueId());
        if (list == null) return null;
        long now = System.currentTimeMillis();
        list.removeIf(r -> r.expiresAt() < now);
        if (senderName == null || senderName.isBlank()) return list.isEmpty() ? null : list.get(list.size() - 1);
        for (Request r : list) {
            Player s = Bukkit.getPlayer(r.sender());
            if (s != null && s.getName().equalsIgnoreCase(senderName)) return r;
        }
        return null;
    }
    private void remove(Request r) { List<Request> list = incoming.get(r.target()); if (list != null) list.remove(r); }
    public void clear(UUID uuid) { incoming.remove(uuid); incoming.values().forEach(l -> l.removeIf(r -> r.sender().equals(uuid))); }
}
