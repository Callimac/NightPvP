package de.nightpvp.standardcommands;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class CombatManager implements Listener {
    private final StandardCommandsPlugin plugin;
    private final Map<UUID, Long> until = new HashMap<>();

    public CombatManager(StandardCommandsPlugin plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        Player attacker = resolvePlayer(event.getDamager());
        Player victim = event.getEntity() instanceof Player p ? p : null;
        if (attacker == null || victim == null || attacker.equals(victim)) return;
        long end = System.currentTimeMillis() + Math.max(1, plugin.getConfig().getLong("combat.duration-seconds", 15)) * 1000L;
        until.put(attacker.getUniqueId(), end);
        until.put(victim.getUniqueId(), end);
        plugin.getTeleportService().cancelForCombat(attacker);
        plugin.getTeleportService().cancelForCombat(victim);
        plugin.getAfkManager().markActive(attacker);
        plugin.getAfkManager().markActive(victim);
        plugin.getFlyManager().handleCombatStart(attacker);
        plugin.getFlyManager().handleCombatStart(victim);
    }

    private Player resolvePlayer(Entity entity) {
        if (entity instanceof Player p) return p;
        if (entity instanceof org.bukkit.entity.Projectile projectile && projectile.getShooter() instanceof Player p) return p;
        return null;
    }

    public boolean inCombat(Player player) {
        return remaining(player) > 0L;
    }

    public long remaining(Player player) {
        long end = until.getOrDefault(player.getUniqueId(), 0L);
        long left = (end - System.currentTimeMillis() + 999L) / 1000L;
        if (left <= 0) until.remove(player.getUniqueId());
        return Math.max(0L, left);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        if (plugin.getConfig().getBoolean("combat.logout-kill", false) && inCombat(event.getPlayer())) {
            event.getPlayer().setHealth(0.0);
        }
        until.remove(event.getPlayer().getUniqueId());
    }
}
