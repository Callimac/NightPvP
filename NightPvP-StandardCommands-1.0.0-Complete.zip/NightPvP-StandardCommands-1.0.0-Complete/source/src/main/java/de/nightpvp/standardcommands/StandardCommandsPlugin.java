package de.nightpvp.standardcommands;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Locale;

public final class StandardCommandsPlugin extends JavaPlugin {
    private DataStore dataStore;
    private RankBridge rankBridge;
    private CooldownManager cooldownManager;
    private CombatManager combatManager;
    private TeleportService teleportService;
    private TpaManager tpaManager;
    private MessageManager messageManager;
    private AfkManager afkManager;
    private FlyManager flyManager;
    private MaintenanceManager maintenanceManager;
    private GuiManager guiManager;
    private EnderChestManager enderChestManager;
    private CommandRouter commandRouter;
    private InvseeManager invseeManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataStore = new DataStore(this);
        rankBridge = new RankBridge(this);
        cooldownManager = new CooldownManager(this);
        guiManager = new GuiManager(this);
        teleportService = new TeleportService(this);
        afkManager = new AfkManager(this);
        flyManager = new FlyManager(this);
        combatManager = new CombatManager(this);
        tpaManager = new TpaManager(this);
        messageManager = new MessageManager(this);
        maintenanceManager = new MaintenanceManager(this);
        enderChestManager = new EnderChestManager(this);
        invseeManager = new InvseeManager();
        commandRouter = new CommandRouter(this);

        getServer().getPluginManager().registerEvents(combatManager, this);
        getServer().getPluginManager().registerEvents(new StandardListener(this), this);
        registerAllCommands();
        afkManager.start();
        startPresentationTask();
        getLogger().info("NightPvP-StandardCommands 1.0.0 wurde aktiviert.");
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) enderChestManager.close(p);
        dataStore.save();
        Bukkit.getScheduler().cancelTasks(this);
    }

    private void registerAllCommands() {
        for (String name : getDescription().getCommands().keySet()) {
            PluginCommand cmd = getCommand(name);
            if (cmd != null) {
                cmd.setExecutor(commandRouter);
                cmd.setTabCompleter(commandRouter);
            }
        }
    }

    private void startPresentationTask() {
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                String list = p.getPlayerListName();
                if (list == null || list.isBlank()) list = p.getName();
                list = list.replace(Text.c("&6[AFK] &r"), "");
                String nick = dataStore.getNick(p.getUniqueId());
                if (nick != null && !nick.isBlank()) {
                    list = list.replace(p.getName(), nick);
                    p.setDisplayName(nick);
                } else {
                    p.setDisplayName(p.getName());
                }
                if (afkManager.isAfk(p)) list = Text.c("&6[AFK] &r") + list;
                p.setPlayerListName(list);
            }
        }, 20L, 20L);
    }

    public int homeLimit(Player p) {
        if (rankBridge.isTeam(p)) return getConfig().getInt("home.limits.TEAM", 20);
        String rank = rankBridge.getRankName(p).toUpperCase(Locale.ROOT);
        return Math.max(0, getConfig().getInt("home.limits." + rank, getConfig().getInt("home.limits.MITGLIED", 1)));
    }

    public void teleportHome(Player p, String name) {
        Location loc = dataStore.getHomes(p.getUniqueId()).get(name.toLowerCase(Locale.ROOT));
        if (loc == null) { Text.send(p, "&e&lHOME &8» &cDu besitzt kein Home mit dem Namen &e" + name + "&c."); return; }
        if (!teleportService.isSafeExact(loc)) { Text.send(p, "&e&lHOME &8» &cDas Home &e" + name + " &cist aktuell blockiert oder nicht sicher."); return; }
        p.closeInventory();
        teleportService.delayed(p, loc, "HOME", "&e", "&e&lHOME &8» &7Du wurdest zu deinem Home &e" + name + " &7teleportiert.", () -> teleportService.isSafeExact(loc));
    }

    public void teleportWarp(Player p, String name) {
        Location loc = dataStore.getWarp(name);
        if (loc == null) { Text.send(p, "&6&lWARP &8» &cDieser Warp existiert nicht."); return; }
        if (!teleportService.isSafeExact(loc)) { Text.send(p, "&6&lWARP &8» &cDieser Warp ist aktuell blockiert oder nicht sicher."); return; }
        p.closeInventory();
        teleportService.delayed(p, loc, "WARP", "&6", "&6&lWARP &8» &7Du wurdest zu &6" + name + " &7teleportiert.", () -> teleportService.isSafeExact(loc));
    }

    public DataStore getDataStore(){return dataStore;} public RankBridge getRankBridge(){return rankBridge;}
    public CooldownManager getCooldownManager(){return cooldownManager;} public CombatManager getCombatManager(){return combatManager;}
    public TeleportService getTeleportService(){return teleportService;} public TpaManager getTpaManager(){return tpaManager;}
    public MessageManager getMessageManager(){return messageManager;} public AfkManager getAfkManager(){return afkManager;}
    public FlyManager getFlyManager(){return flyManager;} public MaintenanceManager getMaintenanceManager(){return maintenanceManager;}
    public GuiManager getGuiManager(){return guiManager;} public EnderChestManager getEnderChestManager(){return enderChestManager;} public InvseeManager getInvseeManager(){return invseeManager;}
}
