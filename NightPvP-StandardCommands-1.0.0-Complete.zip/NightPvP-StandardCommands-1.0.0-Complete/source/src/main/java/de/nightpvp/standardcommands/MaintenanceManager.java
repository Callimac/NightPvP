package de.nightpvp.standardcommands;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public final class MaintenanceManager {
    private final StandardCommandsPlugin plugin;
    public MaintenanceManager(StandardCommandsPlugin plugin) { this.plugin = plugin; }

    public boolean enabled() { return plugin.getConfig().getBoolean("maintenance.enabled", false); }
    public void setEnabled(boolean enabled) {
        plugin.getConfig().set("maintenance.enabled", enabled); plugin.saveConfig();
        if (enabled) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!canBypass(p)) Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (p.isOnline() && !canBypass(p)) p.kickPlayer(Text.c("&4&lNightPvP\n\n&cDer Server befindet sich aktuell in Wartung.\n&7Bitte versuche es später erneut."));
                }, 60L);
            }
        }
    }
    public boolean canBypass(Player p) { return p.hasPermission("nightpvp.standardcommands.maintenance.bypass") || plugin.getRankBridge().isTeam(p); }
    public String motd() {
        String l1 = plugin.getConfig().getString(enabled() ? "maintenance.motd-line1" : "motd.line1", "&5&lNightPvP");
        String l2 = plugin.getConfig().getString(enabled() ? "maintenance.motd-line2" : "motd.line2", "&7Survival");
        return Text.c(l1 + "\n" + l2);
    }
}
