package de.nightpvp.standardcommands;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public final class RankBridge {
    private static final Set<String> TEAM = Set.of("ASK", "SUPPORTER", "BUILDER", "DEVELOPER", "MOD", "ADMIN");
    private final StandardCommandsPlugin plugin;

    public RankBridge(StandardCommandsPlugin plugin) {
        this.plugin = plugin;
    }

    public String getRankName(Player player) {
        if (player == null) return "MITGLIED";
        String reflected = reflectedOnlineRank(player);
        if (reflected != null) return reflected;
        return "MITGLIED";
    }

    public String getRankName(UUID uuid) {
        Plugin display = Bukkit.getPluginManager().getPlugin("NightPvP-DisplaySystem");
        if (display != null && display.isEnabled()) {
            try {
                Method dm = display.getClass().getMethod("getDataManager");
                Object dataManager = dm.invoke(display);
                Method getRank = dataManager.getClass().getMethod("getRank", UUID.class);
                Object rank = getRank.invoke(dataManager, uuid);
                if (rank instanceof Enum<?> e) return e.name().toUpperCase(Locale.ROOT);
                if (rank != null) return rank.toString().toUpperCase(Locale.ROOT);
            } catch (ReflectiveOperationException ignored) {}
        }
        OfflinePlayer off = Bukkit.getOfflinePlayer(uuid);
        if (off.isOnline() && off.getPlayer() != null) return getRankName(off.getPlayer());
        return "MITGLIED";
    }

    private String reflectedOnlineRank(Player player) {
        Plugin display = Bukkit.getPluginManager().getPlugin("NightPvP-DisplaySystem");
        if (display == null || !display.isEnabled()) return null;
        try {
            Object manager = display.getClass().getMethod("getRankManager").invoke(display);
            Object rank = manager.getClass().getMethod("getRank", Player.class).invoke(manager, player);
            if (rank instanceof Enum<?> e) return e.name().toUpperCase(Locale.ROOT);
            return rank == null ? null : rank.toString().toUpperCase(Locale.ROOT);
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }

    public boolean isTeam(Player player) {
        return player != null && (player.hasPermission("nightpvp.standardcommands.team") || TEAM.contains(getRankName(player)));
    }

    public boolean isTeam(UUID uuid) {
        Player p = Bukkit.getPlayer(uuid);
        if (p != null) return isTeam(p);
        return TEAM.contains(getRankName(uuid));
    }

    public boolean isModOrAdmin(Player player) {
        if (player == null) return false;
        String rank = getRankName(player);
        return rank.equals("MOD") || rank.equals("ADMIN") || player.hasPermission("nightpvp.standardcommands.admin");
    }

    public boolean isDeveloperPlus(Player player) {
        if (player == null) return false;
        String rank = getRankName(player);
        return rank.equals("DEVELOPER") || rank.equals("MOD") || rank.equals("ADMIN") || player.hasPermission("nightpvp.standardcommands.tppos");
    }

    public boolean atLeastPlayerRank(Player player, String minimum) {
        int current = playerRankWeight(getRankName(player));
        int required = playerRankWeight(minimum);
        return current >= required || isTeam(player);
    }

    private int playerRankWeight(String rank) {
        return switch (rank.toUpperCase(Locale.ROOT)) {
            case "MITGLIED" -> 0;
            case "ELITE" -> 1;
            case "ULTIMATE" -> 2;
            case "TITAN" -> 3;
            case "GOD" -> 4;
            case "SUPREME" -> 5;
            default -> TEAM.contains(rank.toUpperCase(Locale.ROOT)) ? 99 : 0;
        };
    }
}
