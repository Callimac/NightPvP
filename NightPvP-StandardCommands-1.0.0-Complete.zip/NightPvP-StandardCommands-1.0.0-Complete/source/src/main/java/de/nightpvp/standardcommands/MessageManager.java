package de.nightpvp.standardcommands;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.util.*;

public final class MessageManager {
    private final StandardCommandsPlugin plugin;
    private final Map<UUID, UUID> lastPartner = new HashMap<>();

    public MessageManager(StandardCommandsPlugin plugin) { this.plugin = plugin; }

    public void send(Player sender, Player target, String message) {
        if (sender.equals(target)) { Text.send(sender, "&b&lPN &8» &cDu kannst dir nicht selbst schreiben."); return; }
        if (plugin.getDataStore().getIgnored(target.getUniqueId()).contains(sender.getUniqueId()) && !plugin.getRankBridge().isTeam(sender)) {
            Text.send(sender, "&b&lPN &8» &7Du &8→ &b" + target.getName() + " &8» &f" + message);
            lastPartner.put(sender.getUniqueId(), target.getUniqueId());
            return;
        }
        Text.send(sender, "&b&lPN &8» &7Du &8→ &b" + target.getName() + " &8» &f" + message);
        Text.send(target, "&b&lPN &8» &b" + sender.getName() + " &8→ &7Dir &8» &f" + message);
        target.playSound(target.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.5f, 1.4f);
        if (plugin.getAfkManager().isAfk(target)) Text.send(sender, "&6&lAFK &8» &7" + target.getName() + " ist aktuell &6AFK&7.");
        lastPartner.put(sender.getUniqueId(), target.getUniqueId());
        lastPartner.put(target.getUniqueId(), sender.getUniqueId());
    }

    public void reply(Player sender, String message) {
        UUID id = lastPartner.get(sender.getUniqueId());
        if (id == null) { Text.send(sender, "&b&lPN &8» &cDu hast aktuell niemanden, dem du antworten kannst."); return; }
        Player target = Bukkit.getPlayer(id);
        if (target == null) { Text.send(sender, "&b&lPN &8» &cDieser Spieler ist nicht mehr online."); return; }
        send(sender, target, message);
    }

    public void toggleIgnore(Player player, OfflinePlayer target) {
        if (target.getUniqueId().equals(player.getUniqueId())) { Text.send(player, "&b&lPN &8» &cDu kannst dich nicht selbst ignorieren."); return; }
        Player online = target.getPlayer();
        if (online != null && plugin.getRankBridge().isTeam(online)) { Text.send(player, "&b&lPN &8» &cTeammitglieder können nicht ignoriert werden."); return; }
        Set<UUID> set = new LinkedHashSet<>(plugin.getDataStore().getIgnored(player.getUniqueId()));
        if (set.remove(target.getUniqueId())) Text.send(player, "&b&lPN &8» &7Du ignorierst &b" + target.getName() + " &7nicht mehr.");
        else { set.add(target.getUniqueId()); Text.send(player, "&b&lPN &8» &7Du ignorierst jetzt &b" + target.getName() + "&7."); }
        plugin.getDataStore().setIgnored(player.getUniqueId(), set);
    }

    public void showIgnored(Player player) {
        Set<UUID> set = plugin.getDataStore().getIgnored(player.getUniqueId());
        if (set.isEmpty()) { Text.send(player, "&b&lPN &8» &7Du ignorierst aktuell keine Spieler."); return; }
        StringJoiner join = new StringJoiner("&8, &b");
        for (UUID id : set) {
            String n = plugin.getDataStore().getKnownName(id);
            join.add(n == null ? id.toString().substring(0, 8) : n);
        }
        Text.send(player, "&b&lPN &8» &7Ignorierte Spieler: &b" + join);
    }

    public void clear(UUID uuid) { lastPartner.remove(uuid); }
}
