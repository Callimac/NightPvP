package de.nightpvp.standardcommands;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public final class Text {
    private Text() {}

    public static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }

    public static void send(CommandSender sender, String message) {
        sender.sendMessage(c(message));
    }

    public static String prefix(String name, String color) {
        return c(color + "&l" + name + " &8» &7");
    }

    public static void overview(CommandSender sender, String system, String color, String... commands) {
        send(sender, "&8&m--------------------------------");
        send(sender, color + "&l✦ " + system + " • Befehlsübersicht ✦");
        sender.sendMessage("");
        for (String command : commands) send(sender, command);
        sender.sendMessage("");
        send(sender, "&8&m--------------------------------");
    }
}
