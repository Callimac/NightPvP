package de.nightpvp.standardcommands;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.BooleanSupplier;

public final class TeleportService {
    private record Pending(BukkitTask task, Location start, String prefix, String color) {}
    private final StandardCommandsPlugin plugin;
    private final Map<UUID, Pending> pending = new HashMap<>();

    public TeleportService(StandardCommandsPlugin plugin) { this.plugin = plugin; }

    public void delayed(Player player, Location target, String system, String color, String success, BooleanSupplier safetyCheck) {
        if (plugin.getCombatManager().inCombat(player)) {
            Text.send(player, color + "&l" + system + " &8» &cDu kannst dich während eines Kampfes nicht teleportieren.");
            return;
        }
        cancelSilently(player);
        int delay = Math.max(1, plugin.getConfig().getInt("teleport.delay-seconds", 3));
        Location start = player.getLocation().clone();
        Text.send(player, color + "&l" + system + " &8» &7Du wirst in " + color + delay + " Sekunden &7teleportiert.");
        final int[] left = {delay};
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline()) { cancelSilently(player); return; }
            Location now = player.getLocation();
            if (now.getWorld() != start.getWorld() || now.distanceSquared(start) > 0.0001) {
                Text.send(player, color + "&l" + system + " &8» &cTeleportation abgebrochen, da du dich bewegt hast.");
                cancelSilently(player);
                return;
            }
            if (plugin.getCombatManager().inCombat(player)) {
                Text.send(player, color + "&l" + system + " &8» &cTeleportation abgebrochen, da du dich im Kampf befindest.");
                cancelSilently(player);
                return;
            }
            if (left[0] <= 0) {
                if (safetyCheck != null && !safetyCheck.getAsBoolean()) {
                    Text.send(player, color + "&l" + system + " &8» &cTeleportation abgebrochen. Das Ziel ist nicht mehr sicher.");
                    cancelSilently(player);
                    return;
                }
                plugin.getDataStore().setBackLocation(player.getUniqueId(), player.getLocation());
                player.teleport(target);
                Text.send(player, success);
                cancelSilently(player);
                return;
            }
            Text.send(player, color + "&l" + system + " &8» &7Teleportation in " + color + left[0] + "&7...");
            left[0]--;
        }, 0L, 20L);
        pending.put(player.getUniqueId(), new Pending(task, start, system, color));
    }

    public void cancelForCombat(Player player) {
        Pending p = pending.remove(player.getUniqueId());
        if (p != null) {
            p.task.cancel();
            Text.send(player, p.color + "&l" + p.prefix + " &8» &cTeleportation abgebrochen, da du dich im Kampf befindest.");
        }
    }

    public void cancelSilently(Player player) {
        Pending p = pending.remove(player.getUniqueId());
        if (p != null) p.task.cancel();
    }

    public boolean isSafeExact(Location loc) {
        if (loc == null || loc.getWorld() == null) return false;
        int x = loc.getBlockX(), y = loc.getBlockY(), z = loc.getBlockZ();
        if (y <= loc.getWorld().getMinHeight() + 1 || y >= loc.getWorld().getMaxHeight() - 2) return false;
        Block feet = loc.getWorld().getBlockAt(x, y, z);
        Block head = loc.getWorld().getBlockAt(x, y + 1, z);
        Block ground = loc.getWorld().getBlockAt(x, y - 1, z);
        return passable(feet) && passable(head) && safeGround(ground);
    }

    private boolean passable(Block block) {
        Material m = block.getType();
        return block.isPassable() && m != Material.LAVA && m != Material.FIRE && m != Material.SOUL_FIRE && m != Material.CACTUS && m != Material.SWEET_BERRY_BUSH;
    }

    private boolean safeGround(Block block) {
        Material m = block.getType();
        if (block.isPassable() || m.isAir()) return false;
        return m != Material.LAVA && m != Material.FIRE && m != Material.SOUL_FIRE && m != Material.CACTUS && m != Material.MAGMA_BLOCK && m != Material.CAMPFIRE && m != Material.SOUL_CAMPFIRE;
    }

    public Location findSafeNear(Location base, int radius, int vertical) {
        if (isSafeExact(base)) return base.clone();
        for (int dy = 0; dy <= vertical; dy++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    for (int sy : new int[]{dy, -dy}) {
                        Location test = base.clone().add(dx, sy, dz);
                        if (isSafeExact(test)) return test;
                    }
                }
            }
        }
        return null;
    }
}
