package de.nightpvp.standardcommands;

import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class InvseeManager {
    public record Session(UUID target, boolean editable) {}
    private final Map<UUID, Session> sessions = new HashMap<>();
    public void open(Player viewer, Player target, boolean editable) {
        sessions.put(viewer.getUniqueId(), new Session(target.getUniqueId(), editable));
        viewer.openInventory(target.getInventory());
        Text.send(viewer, "&2&lINVSEE &8» &7Du siehst jetzt das Inventar von &2" + target.getName() + "&7.");
    }
    public Session get(Player viewer) { return sessions.get(viewer.getUniqueId()); }
    public void close(Player viewer) { sessions.remove(viewer.getUniqueId()); }
}
