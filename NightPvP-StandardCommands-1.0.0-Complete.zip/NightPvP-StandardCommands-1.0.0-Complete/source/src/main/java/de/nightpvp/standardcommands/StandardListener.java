package de.nightpvp.standardcommands;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.*;
import org.bukkit.event.server.ServerListPingEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.Set;

public final class StandardListener implements Listener {
    private final StandardCommandsPlugin plugin;
    public StandardListener(StandardCommandsPlugin plugin){this.plugin=plugin;}

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onLogin(PlayerLoginEvent e){
        if(plugin.getMaintenanceManager().enabled() && !plugin.getMaintenanceManager().canBypass(e.getPlayer())){
            e.disallow(PlayerLoginEvent.Result.KICK_OTHER, Text.c("&4&lNightPvP\n\n&cDer Server befindet sich aktuell in Wartung.\n&7Bitte versuche es später erneut."));
        }
    }

    @EventHandler public void onJoin(PlayerJoinEvent e){
        Player p=e.getPlayer(); plugin.getDataStore().recordJoin(p.getUniqueId(),p.getName(),System.currentTimeMillis());
        plugin.getDataStore().clearNick(p.getUniqueId()); plugin.getAfkManager().join(p); plugin.getFlyManager().reset(p); p.resetPlayerTime(); p.resetPlayerWeather();
    }
    @EventHandler public void onQuit(PlayerQuitEvent e){
        Player p=e.getPlayer(); plugin.getEnderChestManager().close(p); plugin.getInvseeManager().close(p);
        plugin.getDataStore().recordQuit(p.getUniqueId(),System.currentTimeMillis()); plugin.getTpaManager().clear(p.getUniqueId()); plugin.getMessageManager().clear(p.getUniqueId()); plugin.getAfkManager().quit(p); plugin.getCooldownManager().clear(p.getUniqueId());
    }
    @EventHandler public void onDeath(PlayerDeathEvent e){ plugin.getDataStore().setBackLocation(e.getEntity().getUniqueId(),e.getEntity().getLocation()); }
    @EventHandler public void onPing(ServerListPingEvent e){ e.setMotd(plugin.getMaintenanceManager().motd()); }

    @EventHandler(ignoreCancelled=true) public void onMove(PlayerMoveEvent e){
        if(e.getTo()==null)return; if(e.getFrom().getBlockX()!=e.getTo().getBlockX()||e.getFrom().getBlockY()!=e.getTo().getBlockY()||e.getFrom().getBlockZ()!=e.getTo().getBlockZ()) plugin.getAfkManager().markActive(e.getPlayer());
    }
    @EventHandler(ignoreCancelled=true) public void onCommand(PlayerCommandPreprocessEvent e){ plugin.getAfkManager().markActive(e.getPlayer()); }
    @EventHandler(ignoreCancelled=true) public void onChat(AsyncPlayerChatEvent e){ plugin.getAfkManager().markActive(e.getPlayer()); }

    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onInteract(PlayerInteractEvent e){
        if(e.getHand()!=EquipmentSlot.HAND)return; Player p=e.getPlayer(); plugin.getAfkManager().markActive(p);
        if(e.getAction()==Action.RIGHT_CLICK_BLOCK){ Block b=e.getClickedBlock(); if(b!=null&&b.getType()==Material.ENDER_CHEST){e.setCancelled(true);plugin.getEnderChestManager().openSelf(p);return;} }
        if((e.getAction()==Action.RIGHT_CLICK_AIR||e.getAction()==Action.RIGHT_CLICK_BLOCK)&&plugin.getEnderChestManager().isVoucher(e.getItem())){
            e.setCancelled(true); plugin.getEnderChestManager().useVoucher(p,e.getItem());
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e){
        if(!(e.getWhoClicked() instanceof Player p))return; String title=e.getView().getTitle(); int raw=e.getRawSlot();
        if(title.equals(GuiManager.HOME_TITLE)){e.setCancelled(true);plugin.getGuiManager().handleHomeClick(p,raw,e.isRightClick(),e.getCurrentItem());return;}
        if(title.equals(GuiManager.HOME_DELETE_TITLE)){e.setCancelled(true);plugin.getGuiManager().handleDeleteConfirm(p,raw);return;}
        if(title.equals(GuiManager.WARP_TITLE)){e.setCancelled(true);plugin.getGuiManager().handleWarpClick(p,raw,e.getCurrentItem());return;}
        if(title.equals(EnderChestManager.CONVERT_TITLE)){e.setCancelled(true);plugin.getEnderChestManager().handleConvert(p,raw);return;}
        if(plugin.getEnderChestManager().isSession(p)){
            EnderChestManager.Session s=plugin.getEnderChestManager().session(p);
            if(raw>=0&&raw<54){
                if(raw==45){e.setCancelled(true);plugin.getEnderChestManager().switchPage(p,-1);return;}
                if(raw==49){e.setCancelled(true);return;}
                if(raw==53){e.setCancelled(true);plugin.getEnderChestManager().switchPage(p,1);return;}
                if(raw<45&&plugin.getEnderChestManager().isLockedSlot(p,raw)){e.setCancelled(true);return;}
            }
            if(!s.editable())e.setCancelled(true);
            return;
        }
        InvseeManager.Session inv=plugin.getInvseeManager().get(p);
        if(inv!=null&&!inv.editable())e.setCancelled(true);
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent e){
        if(!(e.getWhoClicked() instanceof Player p))return;
        if(plugin.getEnderChestManager().isSession(p)){
            EnderChestManager.Session s=plugin.getEnderChestManager().session(p);
            if(!s.editable()){e.setCancelled(true);return;}
            Set<Integer> slots=e.getRawSlots();
            for(int raw:slots){if(raw>=45&&raw<54||raw<45&&plugin.getEnderChestManager().isLockedSlot(p,raw)){e.setCancelled(true);return;}}
        }
        InvseeManager.Session inv=plugin.getInvseeManager().get(p); if(inv!=null&&!inv.editable())e.setCancelled(true);
    }

    @EventHandler public void onClose(InventoryCloseEvent e){
        if(!(e.getPlayer() instanceof Player p))return;
        if(e.getView().getTitle().equals(EnderChestManager.CONVERT_TITLE)) plugin.getEnderChestManager().cancelConfirm(p);
        if(plugin.getEnderChestManager().isSession(p))plugin.getEnderChestManager().close(p);
        plugin.getInvseeManager().close(p);
    }
    @EventHandler public void onCommandSend(PlayerCommandSendEvent e){
        Player p=e.getPlayer(); Set<String> c=e.getCommands(); boolean team=plugin.getRankBridge().isTeam(p);
        if(!team&&!p.hasPermission("nightpvp.standardcommands.setspawn"))c.remove("setspawn");
        if(!team&&!p.hasPermission("nightpvp.standardcommands.tp")){c.remove("tp");c.remove("tphere");}
        if(!plugin.getRankBridge().isDeveloperPlus(p))c.remove("tppos");
        if(!team&&!p.hasPermission("nightpvp.standardcommands.gamemode")){c.remove("gm");c.remove("gamemode");}
        if(!team&&!p.hasPermission("nightpvp.standardcommands.invsee")&&!plugin.getRankBridge().atLeastPlayerRank(p,"SUPREME"))c.remove("invsee");
        if(!team&&!p.hasPermission("nightpvp.standardcommands.heal"))c.remove("heal");
        if(!team&&!p.hasPermission("nightpvp.standardcommands.feed"))c.remove("feed");
        if(!team&&!p.hasPermission("nightpvp.standardcommands.workbench")){c.remove("workbench");c.remove("craft");c.remove("wb");}
        if(!team&&!p.hasPermission("nightpvp.standardcommands.stack"))c.remove("stack");
        if(!team&&!p.hasPermission("nightpvp.standardcommands.fix")){c.remove("fix");c.remove("repair");}
        if(!team&&!p.hasPermission("nightpvp.standardcommands.nick")){c.remove("nick");c.remove("unnick");}
        if(!team&&!plugin.getRankBridge().atLeastPlayerRank(p,"SUPREME"))c.remove("fly");
        if(!team&&!plugin.getRankBridge().atLeastPlayerRank(p,"ULTIMATE"))c.remove("back");
        if(!team&&!plugin.getRankBridge().atLeastPlayerRank(p,"ELITE"))c.remove("near");
        if(!team&&!plugin.getRankBridge().atLeastPlayerRank(p,"TITAN")){c.remove("hat");c.remove("ptime");c.remove("pweather");c.remove("day");c.remove("night");}
        if(!team&&!p.hasPermission("nightpvp.standardcommands.warp.admin")){c.remove("setwarp");c.remove("delwarp");}
        if(!team&&!p.hasPermission("nightpvp.standardcommands.enderchest.others")){c.remove("ecadmin");c.remove("ecslots");c.remove("ecvoucher");}
        if(!team&&!p.hasPermission("nightpvp.standardcommands.broadcast")){c.remove("bc");c.remove("broadcast");}
        if(!team&&!p.hasPermission("nightpvp.standardcommands.warnung"))c.remove("warnung");
        if(!plugin.getRankBridge().isModOrAdmin(p)){c.remove("wartung");c.remove("motd");c.remove("standardcommands");c.remove("stdcmd");}
    }

}
