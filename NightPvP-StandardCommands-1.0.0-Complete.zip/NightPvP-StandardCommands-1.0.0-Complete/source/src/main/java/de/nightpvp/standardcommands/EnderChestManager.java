package de.nightpvp.standardcommands;

import de.nightpvp.guthaben.api.NightPvPGuthabenAPI;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

public final class EnderChestManager {
    public static final String TITLE_PREFIX = Text.c("&5&lENDERCHEST &8• &7Seite ");
    public static final String CONVERT_TITLE = Text.c("&5&lENDERCHEST &8• &7Gutschein");
    public record Session(UUID owner, int page, boolean editable, List<ItemStack> items) {}
    private final StandardCommandsPlugin plugin;
    private final NamespacedKey voucherKey;
    private final Map<UUID, Session> sessions = new HashMap<>();
    private final Set<UUID> confirm = new HashSet<>();

    public EnderChestManager(StandardCommandsPlugin plugin) {
        this.plugin = plugin;
        this.voucherKey = new NamespacedKey(plugin, "ec_slot_voucher");
    }

    public int slotsPerPage() { return 45; }
    public int maxPages() { return Math.max(1, plugin.getConfig().getInt("enderchest.max-pages", 5)); }
    public int maxSlots() { return maxPages() * slotsPerPage(); }
    public int startSlots() { return Math.max(0, Math.min(maxSlots(), plugin.getConfig().getInt("enderchest.start-slots", 9))); }

    public void openSelf(Player p) { open(p, p.getUniqueId(), true, 0); }

    public void open(Player viewer, UUID owner, boolean editable, int page) {
        saveCurrent(viewer);
        sessions.remove(viewer.getUniqueId());
        int unlocked = plugin.getDataStore().getUnlockedEcSlots(owner, startSlots());
        int totalForLoad = Math.max(maxSlots(), unlocked);
        List<ItemStack> items = plugin.getDataStore().getEcItems(owner, totalForLoad);
        int pagesNeeded = Math.max(1, (Math.max(unlocked, 1) + slotsPerPage() - 1) / slotsPerPage());
        int allowedPages = Math.max(1, maxPages());
        page = Math.max(0, Math.min(page, allowedPages - 1));
        Session session = new Session(owner, page, editable, items);
        Inventory inv = Bukkit.createInventory(null, 54, TITLE_PREFIX + (page + 1) + "/" + allowedPages);
        for (int slot = 0; slot < 45; slot++) {
            int global = page * 45 + slot;
            if (global < unlocked && global < items.size()) {
                inv.setItem(slot, items.get(global) == null ? null : items.get(global).clone());
            } else {
                inv.setItem(slot, plugin.getGuiManager().named(Material.BLACK_STAINED_GLASS_PANE, "&c&lGESPERRT", "&7Dieser Enderchest-Slot", "&7ist noch nicht freigeschaltet."));
            }
        }
        if (page > 0) inv.setItem(45, plugin.getGuiManager().named(Material.ARROW, "&5Vorherige Seite"));
        inv.setItem(49, plugin.getGuiManager().named(Material.ENDER_CHEST, "&5&lENDERCHEST", "&7Freigeschaltet: &5" + unlocked + "/" + maxSlots() + " Slots"));
        if (page + 1 < allowedPages) inv.setItem(53, plugin.getGuiManager().named(Material.ARROW, "&5Nächste Seite"));
        viewer.openInventory(inv);
        sessions.put(viewer.getUniqueId(), session);
    }

    public boolean isSession(Player p) { return sessions.containsKey(p.getUniqueId()); }
    public Session session(Player p) { return sessions.get(p.getUniqueId()); }

    public void switchPage(Player viewer, int delta) {
        Session s = sessions.get(viewer.getUniqueId()); if (s == null) return;
        open(viewer, s.owner(), s.editable(), s.page() + delta);
    }

    public boolean isLockedSlot(Player viewer, int rawSlot) {
        Session s = sessions.get(viewer.getUniqueId()); if (s == null || rawSlot < 0 || rawSlot >= 45) return false;
        int unlocked = plugin.getDataStore().getUnlockedEcSlots(s.owner(), startSlots());
        return s.page() * 45 + rawSlot >= unlocked;
    }

    public void saveCurrent(Player viewer) {
        Session s = sessions.get(viewer.getUniqueId());
        if (s == null) return;
        Inventory top = viewer.getOpenInventory().getTopInventory();
        if (!viewer.getOpenInventory().getTitle().startsWith(Text.c("&5&lENDERCHEST"))) return;
        List<ItemStack> items = s.items();
        int required = Math.max(items.size(), (s.page() + 1) * 45);
        while (items.size() < required) items.add(null);
        int unlocked = plugin.getDataStore().getUnlockedEcSlots(s.owner(), startSlots());
        for (int slot=0;slot<45;slot++) {
            int global=s.page()*45+slot;
            if(global>=unlocked) continue;
            ItemStack item=top.getItem(slot);
            items.set(global,item==null?null:item.clone());
        }
        plugin.getDataStore().setEcItems(s.owner(),items);
    }

    public void close(Player viewer) { saveCurrent(viewer); sessions.remove(viewer.getUniqueId()); }

    public ItemStack createVoucher(int amount) {
        ItemStack item = plugin.getGuiManager().named(Material.PAPER, "&5&lENDERCHEST-SLOT GUTSCHEIN",
                "&7Schaltet &51 weiteren Slot", "&7in deiner Enderchest frei.", "", "&7Der Gutschein ist handelbar.", "", "&eRechtsklick &8» &7Einlösen");
        item.setAmount(Math.max(1, Math.min(64, amount)));
        ItemMeta meta=item.getItemMeta(); meta.getPersistentDataContainer().set(voucherKey,PersistentDataType.BYTE,(byte)1); item.setItemMeta(meta); return item;
    }

    public boolean isVoucher(ItemStack item) {
        return item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(voucherKey,PersistentDataType.BYTE);
    }

    public void useVoucher(Player p, ItemStack hand) {
        int unlocked=plugin.getDataStore().getUnlockedEcSlots(p.getUniqueId(),startSlots());
        if(unlocked<maxSlots()){
            plugin.getDataStore().setUnlockedEcSlots(p.getUniqueId(),unlocked+1);
            consumeOne(hand);
            Text.send(p,"&5&lENDERCHEST &8» &7Du hast &51 weiteren Enderchest-Slot &7freigeschaltet.");
            return;
        }
        confirm.add(p.getUniqueId());
        Inventory inv=Bukkit.createInventory(null,27,CONVERT_TITLE);
        for(int i=0;i<27;i++)inv.setItem(i,plugin.getGuiManager().named(Material.BLACK_STAINED_GLASS_PANE," "));
        long value=plugin.getConfig().getLong("enderchest.voucher-value",5000L);
        inv.setItem(13,plugin.getGuiManager().named(Material.PAPER,"&5&lSLOT-GUTSCHEIN","&7Du hast bereits alle","&7verfügbaren Slots freigeschaltet.","","&7Gutscheinwert: &a"+NightPvPGuthabenAPI.format(value)));
        inv.setItem(11,plugin.getGuiManager().named(Material.LIME_STAINED_GLASS_PANE,"&a&lIN GUTHABEN UMWANDELN","&7Wert: &a"+NightPvPGuthabenAPI.format(value)));
        inv.setItem(15,plugin.getGuiManager().named(Material.RED_STAINED_GLASS_PANE,"&c&lGUTSCHEIN BEHALTEN"));
        p.openInventory(inv);
    }

    public void cancelConfirm(Player p){ confirm.remove(p.getUniqueId()); }

    public void handleConvert(Player p,int slot){
        if(!confirm.remove(p.getUniqueId()))return;
        if(slot==11){
            ItemStack hand=p.getInventory().getItemInMainHand();
            if(!isVoucher(hand)){Text.send(p,"&5&lENDERCHEST &8» &cDer Gutschein befindet sich nicht mehr in deiner Hand.");p.closeInventory();return;}
            long value=Math.max(0,plugin.getConfig().getLong("enderchest.voucher-value",5000L));
            if(!NightPvPGuthabenAPI.isReady()||!NightPvPGuthabenAPI.addBalance(p.getUniqueId(),value,"ENDERCHEST_SLOT_VOUCHER")){
                Text.send(p,"&5&lENDERCHEST &8» &cDie Guthaben-Umwandlung ist momentan nicht möglich.");p.closeInventory();return;
            }
            consumeOne(hand); Text.send(p,"&5&lENDERCHEST &8» &7Dein Gutschein wurde in &a"+NightPvPGuthabenAPI.format(value)+" &7umgewandelt.");
        }else Text.send(p,"&5&lENDERCHEST &8» &7Du hast deinen Gutschein behalten.");
        p.closeInventory();
    }

    private void consumeOne(ItemStack item){ if(item.getAmount()<=1)item.setAmount(0); else item.setAmount(item.getAmount()-1); }
}
