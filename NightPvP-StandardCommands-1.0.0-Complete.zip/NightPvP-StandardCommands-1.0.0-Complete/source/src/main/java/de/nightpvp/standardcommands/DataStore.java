package de.nightpvp.standardcommands;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class DataStore {
    private final StandardCommandsPlugin plugin;
    private final File file;
    private final YamlConfiguration data;

    public DataStore(StandardCommandsPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
        this.data = YamlConfiguration.loadConfiguration(file);
    }

    public synchronized void save() {
        try { data.save(file); }
        catch (IOException ex) { plugin.getLogger().severe("data.yml konnte nicht gespeichert werden: " + ex.getMessage()); }
    }

    public synchronized void setSpawn(Location loc) { data.set("spawn", loc); save(); }
    public synchronized Location getSpawn() { return data.getLocation("spawn"); }

    private String p(UUID u) { return "players." + u + "."; }

    public synchronized Map<String, Location> getHomes(UUID uuid) {
        Map<String, Location> result = new LinkedHashMap<>();
        ConfigurationSection sec = data.getConfigurationSection(p(uuid) + "homes");
        if (sec == null) return result;
        for (String key : sec.getKeys(false)) {
            Location loc = sec.getLocation(key);
            if (loc != null) result.put(key, loc);
        }
        return result;
    }

    public synchronized void setHome(UUID uuid, String name, Location loc) {
        data.set(p(uuid) + "homes." + name.toLowerCase(Locale.ROOT), loc); save();
    }
    public synchronized void delHome(UUID uuid, String name) { data.set(p(uuid) + "homes." + name.toLowerCase(Locale.ROOT), null); save(); }

    public synchronized Map<String, Location> getWarps() {
        Map<String, Location> result = new LinkedHashMap<>();
        ConfigurationSection sec = data.getConfigurationSection("warps");
        if (sec == null) return result;
        for (String key : sec.getKeys(false)) {
            Location loc = sec.getLocation(key + ".location");
            if (loc != null) result.put(key, loc);
        }
        return result;
    }
    public synchronized Location getWarp(String name) { return data.getLocation("warps." + name.toLowerCase(Locale.ROOT) + ".location"); }
    public synchronized ItemStack getWarpIcon(String name) { return data.getItemStack("warps." + name.toLowerCase(Locale.ROOT) + ".icon"); }
    public synchronized void setWarp(String name, Location loc) { data.set("warps." + name.toLowerCase(Locale.ROOT) + ".location", loc); save(); }
    public synchronized void setWarpIcon(String name, ItemStack icon) { data.set("warps." + name.toLowerCase(Locale.ROOT) + ".icon", icon == null ? null : icon.clone()); save(); }
    public synchronized void delWarp(String name) { data.set("warps." + name.toLowerCase(Locale.ROOT), null); save(); }

    public synchronized void setBackLocation(UUID uuid, Location loc) { data.set(p(uuid) + "back", loc); save(); }
    public synchronized Location getBackLocation(UUID uuid) { return data.getLocation(p(uuid) + "back"); }

    public synchronized Set<UUID> getIgnored(UUID uuid) {
        Set<UUID> set = new LinkedHashSet<>();
        for (String s : data.getStringList(p(uuid) + "ignored")) {
            try { set.add(UUID.fromString(s)); } catch (IllegalArgumentException ignored) {}
        }
        return set;
    }
    public synchronized void setIgnored(UUID uuid, Set<UUID> values) {
        data.set(p(uuid) + "ignored", values.stream().map(UUID::toString).toList()); save();
    }

    public synchronized void recordJoin(UUID uuid, String name, long now) {
        data.set(p(uuid) + "name", name);
        if (!data.contains(p(uuid) + "firstJoin")) data.set(p(uuid) + "firstJoin", now);
        data.set(p(uuid) + "lastJoin", now); save();
    }
    public synchronized void recordQuit(UUID uuid, long now) { data.set(p(uuid) + "lastSeen", now); save(); }
    public synchronized long getLastSeen(UUID uuid) { return data.getLong(p(uuid) + "lastSeen", 0L); }
    public synchronized long getLastJoin(UUID uuid) { return data.getLong(p(uuid) + "lastJoin", 0L); }
    public synchronized String getKnownName(UUID uuid) { return data.getString(p(uuid) + "name", Bukkit.getOfflinePlayer(uuid).getName()); }

    public synchronized int getUnlockedEcSlots(UUID uuid, int defaultValue) {
        String path = p(uuid) + "ec.unlocked";
        if (!data.contains(path)) { data.set(path, defaultValue); save(); }
        return data.getInt(path, defaultValue);
    }
    public synchronized void setUnlockedEcSlots(UUID uuid, int value) { data.set(p(uuid) + "ec.unlocked", Math.max(0, value)); save(); }

    @SuppressWarnings("unchecked")
    public synchronized List<ItemStack> getEcItems(UUID uuid, int totalSlots) {
        List<?> raw = data.getList(p(uuid) + "ec.items");
        int size = Math.max(totalSlots, raw == null ? 0 : raw.size());
        List<ItemStack> out = new ArrayList<>(Collections.nCopies(size, null));
        if (raw == null) return out;
        for (int i = 0; i < raw.size(); i++) {
            Object o = raw.get(i);
            if (o instanceof ItemStack stack) out.set(i, stack.clone());
        }
        return out;
    }
    public synchronized void setEcItems(UUID uuid, List<ItemStack> items) {
        List<ItemStack> clone = new ArrayList<>(items.size());
        for (ItemStack i : items) clone.add(i == null ? null : i.clone());
        data.set(p(uuid) + "ec.items", clone); save();
    }

    public synchronized String getNick(UUID uuid) { return data.getString(p(uuid) + "nick"); }
    public synchronized void setNick(UUID uuid, String nick) { data.set(p(uuid) + "nick", nick); save(); }
    public synchronized void clearNick(UUID uuid) { data.set(p(uuid) + "nick", null); save(); }
}
