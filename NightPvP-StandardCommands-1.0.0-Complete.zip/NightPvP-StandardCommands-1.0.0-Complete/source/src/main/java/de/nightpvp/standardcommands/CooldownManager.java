package de.nightpvp.standardcommands;

import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class CooldownManager {
    private final StandardCommandsPlugin plugin;
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();

    public CooldownManager(StandardCommandsPlugin plugin) {
        this.plugin = plugin;
    }

    public long remaining(Player player, String key, long seconds) {
        if (plugin.getRankBridge().isTeam(player)) return 0L;
        long now = System.currentTimeMillis();
        long until = cooldowns.getOrDefault(player.getUniqueId(), Map.of()).getOrDefault(key, 0L);
        return Math.max(0L, (until - now + 999L) / 1000L);
    }

    public boolean use(Player player, String key, long seconds) {
        if (plugin.getRankBridge().isTeam(player)) return true;
        if (remaining(player, key, seconds) > 0L) return false;
        cooldowns.computeIfAbsent(player.getUniqueId(), u -> new HashMap<>())
                .put(key, System.currentTimeMillis() + seconds * 1000L);
        return true;
    }

    public long generalSeconds() {
        return Math.max(0, plugin.getConfig().getLong("general.command-cooldown-seconds", 3));
    }

    public void clear(UUID uuid) { cooldowns.remove(uuid); }
}
