NightPvP-StandardCommands 1.0.0
Ziel: Paper 1.21.8 / Java 21

INSTALLATION
1. Server komplett stoppen.
2. NightPvP-Guthaben muss installiert sein.
3. Für automatische Ranglimits/-freischaltungen sollte NightPvP-DisplaySystem installiert sein.
4. NightPvP-StandardCommands-1.0.0-Paper1.21.8.jar in plugins/ legen.
5. Server normal neu starten. Kein /reload verwenden.

ENTHALTEN
- SPAWN: /spawn, /setspawn, 3s, Bewegung/Combat-Abbruch.
- HOME: /home GUI mit Betten, /home <Name>, /sethome, /delhome, sichere Positionen.
  Limits: Mitglied 1, Elite 2, Ultimate 3, Titan 5, GOD 7, Supreme 15, Team 20.
- TPA: /tpa, /tpahere, /tpaccept, /tpdeny, klickbare Buttons, 60s Ablauf, 10s Cooldown.
- TEAM-TP: /tp, /tphere, /tppos.
- PN: /msg, /r, /ignore.
- WARP: /warp GUI, /warp <Name>, /setwarp, /delwarp, /warp icon <Name>.
- HEAL/FEED: Permissions; Heal 3 Min. Cooldown für Spieler, Team ohne Cooldown.
- FLY: ab Supreme, nicht im Combat; Team darf Fly im Combat; Rejoin deaktiviert Fly.
- GM: /gm 1|2|3 nur Team.
- INVSEE: ab Supreme nur ansehen, Team darf bearbeiten.
- ENDERCHEST: /ec, erweiterte Seiten-Enderchest, Slot-Gutscheine, Gutschein-Geldumwandlung mit Bestätigung.
- CRAFT: /workbench, /craft, /wb.
- BACK: ab Ultimate, sichere Rückkehrposition, 3s + Combat.
- NEAR: ab Elite, Standard 100 Blöcke.
- SEEN, AFK, NICK/UNNICK, HAT, FIX/REPAIR, PTIME/DAY/NIGHT, PWEATHER, TRASH, STACK.
- BC/BROADCAST in hellrot, WARNUNG in dunkelrot + Sound.
- WARTUNG: Join-Sperre, Wartungs-MOTD, persistenter Status.
- MOTD: /motd zeile1, /motd zeile2, /motd anzeigen.
- /standardcommands: Admin-Einstellungen für Near/AFK.

BEWUSST NICHT ENTHALTEN
- /top / Ranking: soll als separates NightPvP-Ranking-Plugin entstehen.

ALLGEMEINE REGELN
- Normaler Spieler-Command-Cooldown standardmäßig 3 Sekunden pro Befehl.
- Teamcommands ohne Anti-Spam-Cooldown.
- Combat-Dauer standardmäßig 15 Sekunden nach dem letzten PvP-Treffer.
- Teleports standardmäßig 3 Sekunden; echte Positionsbewegung bricht ab, Blickrichtung nicht.
- Teleportziele werden auf Sicherheit geprüft.

ENDERHEST
- Standard: 5 Seiten.
- GUI reserviert die untere Reihe für Seitennavigation/Status, daher 45 Speicherplätze pro Seite (225 Slots bei 5 Seiten).
- Start: 9 freigeschaltete Slots.
- /ecadmin maxpages <Anzahl>
- /ecadmin startslots <Anzahl>
- /ecadmin voucherwert <Betrag>
- /ecvoucher give <Spieler> [Anzahl]
- /ecslots <Spieler> [add|remove|set] [Anzahl]
- Slot-Gutscheine sind handelbar.
- Am aktuellen Maximum öffnet sich eine Bestätigung: in Guthaben umwandeln oder behalten.
- Die Auszahlung läuft über NightPvPGuthabenAPI.

RANG/PERMISSIONS
Automatisch über NightPvP-DisplaySystem erkannt werden u.a. Home-Limits sowie Elite/Ultimate/Titan/Supreme/Team-Regeln.
Nicht abschließend einem Spielerrang zugewiesene Perks bleiben bewusst über Permissions steuerbar (z.B. heal, feed, workbench, fix, stack, nick).
Creator/YouTuber erhalten /nick über nightpvp.standardcommands.nick.

WICHTIGE ERSTE TESTS
- /spawn + Bewegung + Combat.
- /sethome an sicherem/unsicherem Ort; /home GUI.
- /tpa und /tpahere mit Klickbuttons.
- /warp GUI + /warp icon.
- Supreme /fly und /invsee (read-only); Team /invsee edit.
- /ec, Slot-Gutschein, max. Slots, Umwandlungsbestätigung.
- /fix, /repair all, /hat mit Item-Stack.
- /wartung an/aus + Serverliste + Joinblock.
- /motd zeile1/zeile2.

HINWEIS NICK
Der Nick wird in der Bukkit-Displayanzeige und Tablist gesetzt. Ein vollständiger clientseitiger Ersatz des echten Minecraft-Profilnamens über dem Spieler erfordert eine separate Packet/Profile-Lösung und ist in 1.0.0 noch nicht enthalten.
