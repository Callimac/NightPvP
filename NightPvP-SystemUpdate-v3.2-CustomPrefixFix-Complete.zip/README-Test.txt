NightPvP DisplaySystem 1.5.4 - CustomPrefix Workflow Fix

Geändert:
- echter Vanilla-Amboss statt künstlichem ANVIL-Inventar
- Custom-Prefix-Gutschein bleibt erhalten, bis die Anfrage erfolgreich gespeichert wurde
- erfolgreiche Einreichung: Amboss schließt sofort
- danach Meldung: Prefix wird von einem Teammitglied bearbeitet
- zu kurz: "Prefix zu kurz" (Minimum 2 sichtbare Zeichen)
- zu lang: "Prefix zu lang" (Maximum 6 sichtbare Zeichen)
- Farben + Fett bleiben erlaubt; Farb-/Formatcodes zählen nicht zur sichtbaren Länge
- angenommene Anfrage: Online-Spieler bekommt Meldung sofort; Offline-Spieler beim nächsten Join
- abgelehnte Anfrage: Online-Spieler bekommt Meldung sofort; Offline-Spieler beim nächsten Join
- bei Ablehnung wird der Custom-Prefix-Gutschein zurückgegeben (online sofort, offline beim nächsten Join)
- Review-Team wird bei neuer Anfrage informiert
- Review-Berechtigte sehen offene Aufträge beim Join
- /prefix review und /prefix reviewe bleiben unterstützt

Testablauf:
1. /prefix customvoucher
2. Gutschein rechtsklicken
3. im Amboss z.B. "KING" eingeben
4. Ergebnis anklicken
5. Amboss muss schließen + Bearbeitungs-Meldung erscheinen
6. /prefix review als berechtigtes Teammitglied
7. Linksklick = annehmen / Rechtsklick = ablehnen
8. Annahme/Ablehnung online und offline testen
