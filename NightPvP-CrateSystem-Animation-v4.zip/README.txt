NightPvP Crate-System 3.0

Befehle:
 /crate give <spieler> <crate> <menge>
 /crate preview <crate>
 /crate reload

Ablauf:
 1. Spieler erhält eine NightPvP-Crate.
 2. Rechtsklick mit der Crate in der Hand.
 3. Settings-GUI:
    - Mit Animation
    - Mögliche Gewinne
    - Ohne Animation
    - Abbrechen
 4. Beim Öffnen wird genau eine Crate verbraucht.
 5. Gewinnchancen werden aus config.yml gelesen.

Eigene Crates:
 Kopiere in config.yml einen vorhandenen crates.<name>-Block
 und ändere Namen, Settings und Rewards.

Reward-Typen:
 item
 money
 command

Money-Rewards:
 Der Befehl ist über money-reward-command konfigurierbar.
