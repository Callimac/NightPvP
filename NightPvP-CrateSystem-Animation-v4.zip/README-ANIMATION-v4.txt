NightPvP Crate Animation v4

Neue Animation:
- 3 Zeilen / 27 Slots
- Obere Reihe = Rahmen
- Mittlere Reihe = 9 durchlaufende Gewinne
- Untere Reihe = Rahmen
- Slot 13 ist die Mitte
- Über und unter Slot 13 ist die Hauptgewinn-Markierung
- Am Ende wird der ausgeloste Gewinn garantiert in Slot 13 angezeigt

Config:
crates.<crate>.settings.animation-steps
crates.<crate>.settings.animation-speed
crates.<crate>.settings.animation-sound
crates.<crate>.settings.border-material
crates.<crate>.settings.center-marker-material
crates.<crate>.settings.close-delay

Die Gewinnchancen bleiben unverändert.
