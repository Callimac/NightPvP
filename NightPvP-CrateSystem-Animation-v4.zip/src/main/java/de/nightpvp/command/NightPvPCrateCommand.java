package de.nightpvp.command;

import de.nightpvp.crate.NightPvPCrateManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public final class NightPvPCrateCommand implements TabExecutor {

    private final NightPvPCrateManager manager;

    public NightPvPCrateCommand(
            NightPvPCrateManager manager
    ) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(
            CommandSender sender,
            Command command,
            String label,
            String[] args
    ) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "give" -> handleGive(sender, args);
            case "preview" -> handlePreview(sender, args);
            case "reload" -> handleReload(sender);
            default -> sendHelp(sender);
        }

        return true;
    }

    private void handleGive(
            CommandSender sender,
            String[] args
    ) {
        if (!sender.hasPermission(
                "nightpvp.crate.admin"
        )) {
            sender.sendMessage(
                    ChatColor.RED
                            + "NightPvP: Keine Berechtigung."
            );
            return;
        }

        if (args.length != 4) {
            sender.sendMessage(
                    ChatColor.RED
                            + "/crate give <spieler> <crate> <menge>"
            );
            return;
        }

        Player target =
                Bukkit.getPlayerExact(args[1]);

        if (target == null) {
            sender.sendMessage(
                    ChatColor.RED
                            + "NightPvP: Spieler nicht online."
            );
            return;
        }

        if (!manager.exists(args[2])) {
            sender.sendMessage(
                    ChatColor.RED
                            + "NightPvP: Crate nicht gefunden."
            );
            return;
        }

        int amount;

        try {
            amount = Integer.parseInt(args[3]);
        } catch (NumberFormatException exception) {
            sender.sendMessage(
                    ChatColor.RED
                            + "NightPvP: Ungültige Menge."
            );
            return;
        }

        if (amount < 1 || amount > 64) {
            sender.sendMessage(
                    ChatColor.RED
                            + "NightPvP: Menge muss 1-64 sein."
            );
            return;
        }

        target.getInventory().addItem(
                manager.createCrateItem(
                        args[2],
                        amount
                )
        );

        sender.sendMessage(
                ChatColor.GREEN
                        + "NightPvP: "
                        + amount
                        + "x "
                        + manager.getDisplayName(args[2])
                        + ChatColor.GREEN
                        + " an "
                        + target.getName()
                        + " gegeben."
        );
    }

    private void handlePreview(
            CommandSender sender,
            String[] args
    ) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(
                    ChatColor.RED
                            + "NightPvP: Nur Spieler."
            );
            return;
        }

        if (args.length != 2) {
            player.sendMessage(
                    ChatColor.RED
                            + "/crate preview <crate>"
            );
            return;
        }

        if (!manager.exists(args[1])) {
            player.sendMessage(
                    ChatColor.RED
                            + "NightPvP: Crate nicht gefunden."
            );
            return;
        }

        manager.openPreview(
                player,
                args[1]
        );
    }

    private void handleReload(
            CommandSender sender
    ) {
        if (!sender.hasPermission(
                "nightpvp.crate.admin"
        )) {
            sender.sendMessage(
                    ChatColor.RED
                            + "NightPvP: Keine Berechtigung."
            );
            return;
        }

        manager.reload();

        sender.sendMessage(
                ChatColor.GREEN
                        + "NightPvP: Config neu geladen."
        );
    }

    private void sendHelp(
            CommandSender sender
    ) {
        sender.sendMessage(
                ChatColor.LIGHT_PURPLE
                        + "---- NightPvP Crates ----"
        );

        sender.sendMessage(
                ChatColor.YELLOW
                        + "/crate give <spieler> <crate> <menge>"
        );

        sender.sendMessage(
                ChatColor.YELLOW
                        + "/crate preview <crate>"
        );

        sender.sendMessage(
                ChatColor.YELLOW
                        + "/crate reload"
        );
    }

    @Override
    public List<String> onTabComplete(
            CommandSender sender,
            Command command,
            String alias,
            String[] args
    ) {
        List<String> suggestions =
                new ArrayList<>();

        if (args.length == 1) {
            suggestions.add("give");
            suggestions.add("preview");
            suggestions.add("reload");

            return filter(
                    suggestions,
                    args[0]
            );
        }

        if (args.length == 2
                && args[0].equalsIgnoreCase("give")) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                suggestions.add(player.getName());
            }

            return filter(
                    suggestions,
                    args[1]
            );
        }

        if (args.length == 2
                && args[0].equalsIgnoreCase("preview")) {
            suggestions.addAll(
                    manager.getCrateIds()
            );

            return filter(
                    suggestions,
                    args[1]
            );
        }

        if (args.length == 3
                && args[0].equalsIgnoreCase("give")) {
            suggestions.addAll(
                    manager.getCrateIds()
            );

            return filter(
                    suggestions,
                    args[2]
            );
        }

        return suggestions;
    }

    private List<String> filter(
            List<String> values,
            String input
    ) {
        List<String> result =
                new ArrayList<>();

        for (String value : values) {
            if (value.toLowerCase()
                    .startsWith(
                            input.toLowerCase()
                    )) {
                result.add(value);
            }
        }

        return result;
    }
}
