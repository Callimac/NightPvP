package de.nightpvp.crate;

import de.nightpvp.NightPvP;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public final class NightPvPCrateManager {

    public enum MenuType {
        NONE,
        SETTINGS,
        PREVIEW,
        OPENING
    }

    private final NightPvP plugin;
    private final NamespacedKey crateKey;
    private final Random random = new Random();

    private final Map<UUID, String> activeCrate = new HashMap<>();
    private final Map<UUID, MenuType> menuType = new HashMap<>();
    private final Set<UUID> opening = new HashSet<>();

    public NightPvPCrateManager(NightPvP plugin) {
        this.plugin = plugin;
        this.crateKey = new NamespacedKey(plugin, "nightpvp_crate_type");
    }

    public void reload() {
        plugin.reloadConfig();
    }

    public void shutdown() {
        activeCrate.clear();
        menuType.clear();
        opening.clear();
    }

    public boolean exists(String crateId) {
        if (crateId == null || crateId.isBlank()) {
            return false;
        }

        return plugin.getConfig().isConfigurationSection(
                "crates." + crateId.toLowerCase(Locale.ROOT)
        );
    }

    public Set<String> getCrateIds() {
        ConfigurationSection section =
                plugin.getConfig().getConfigurationSection("crates");

        if (section == null) {
            return Collections.emptySet();
        }

        return section.getKeys(false);
    }

    public String getDisplayName(String crateId) {
        return color(plugin.getConfig().getString(
                "crates." + crateId + ".display-name",
                "&d&lNightPvP Crate"
        ));
    }

    public ItemStack createCrateItem(String crateId, int amount) {
        ItemStack item = new ItemStack(
                Material.PLAYER_HEAD,
                Math.max(1, Math.min(64, amount))
        );

        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }

        meta.setDisplayName(getDisplayName(crateId));
        meta.setLore(List.of(
                color("&7Rechtsklick zum Öffnen"),
                color("&8"),
                color("&bMögliche Gewinne im Menü ansehen"),
                color("&8"),
                color("&d&lNightPvP")
        ));

        meta.getPersistentDataContainer().set(
                crateKey,
                PersistentDataType.STRING,
                crateId.toLowerCase(Locale.ROOT)
        );

        item.setItemMeta(meta);
        return item;
    }

    public String getCrateId(ItemStack item) {
        if (item == null
                || item.getType() != Material.PLAYER_HEAD
                || !item.hasItemMeta()) {
            return null;
        }

        return item.getItemMeta()
                .getPersistentDataContainer()
                .get(crateKey, PersistentDataType.STRING);
    }

    public MenuType getMenuType(Player player) {
        return menuType.getOrDefault(player.getUniqueId(), MenuType.NONE);
    }

    public String getActiveCrate(Player player) {
        return activeCrate.get(player.getUniqueId());
    }

    public boolean isOpening(Player player) {
        return opening.contains(player.getUniqueId());
    }

    public void openSettings(Player player, String crateId) {
        if (!exists(crateId)) {
            player.sendMessage(color("&cNightPvP: Diese Crate existiert nicht."));
            return;
        }

        activeCrate.put(player.getUniqueId(), crateId);
        menuType.put(player.getUniqueId(), MenuType.SETTINGS);

        Inventory inventory = Bukkit.createInventory(
                player,
                27,
                color(plugin.getConfig().getString(
                        "crates." + crateId + ".settings.menu-title",
                        "&8&lNightPvP &r&7» &fCrate Einstellungen"
                ))
        );

        fill(inventory, Material.BLACK_STAINED_GLASS_PANE);

        inventory.setItem(11, simple(
                Material.LIME_DYE,
                color("&a&lMit Animation"),
                color("&7Öffnet die NightPvP Crate"),
                color("&7mit Gewinnanimation."),
                color("&eKlicken zum Öffnen")
        ));

        inventory.setItem(13, simple(
                Material.CHEST,
                color("&b&lMögliche Gewinne"),
                color("&7Zeigt alle Items und"),
                color("&7deren Gewinnchancen."),
                color("&eKlicken zum Anzeigen")
        ));

        inventory.setItem(15, simple(
                Material.RED_DYE,
                color("&c&lOhne Animation"),
                color("&7Der Gewinn wird sofort"),
                color("&7ausgelost und ausgegeben."),
                color("&eKlicken zum Öffnen")
        ));

        inventory.setItem(22, simple(
                Material.BARRIER,
                color("&c&lAbbrechen"),
                color("&7Menü schließen")
        ));

        player.openInventory(inventory);
    }

    public void openPreview(Player player, String crateId) {
        if (!exists(crateId)) {
            return;
        }

        activeCrate.put(player.getUniqueId(), crateId);
        menuType.put(player.getUniqueId(), MenuType.PREVIEW);

        Inventory inventory = Bukkit.createInventory(
                player,
                54,
                color(plugin.getConfig().getString(
                        "crates." + crateId + ".settings.preview-title",
                        "&8&lNightPvP &r&7» &fMögliche Gewinne"
                ))
        );

        fill(inventory, Material.GRAY_STAINED_GLASS_PANE);

        List<NightPvPCrateReward> rewards = getRewards(crateId);
        int[] slots = {
                10, 11, 12, 13, 14, 15, 16,
                19, 20, 21, 22, 23, 24, 25,
                28, 29, 30, 31, 32, 33, 34,
                37, 38, 39, 40, 41, 42, 43
        };

        for (int i = 0; i < rewards.size() && i < slots.length; i++) {
            inventory.setItem(
                    slots[i],
                    createRewardIcon(rewards.get(i), false)
            );
        }

        inventory.setItem(49, simple(
                Material.ARROW,
                color("&e&lZurück"),
                color("&7Zurück zu den NightPvP Crate Einstellungen")
        ));

        player.openInventory(inventory);
    }

    public void startOpening(
            Player player,
            String crateId,
            boolean withAnimation
    ) {
        if (!exists(crateId)) {
            player.sendMessage(color("&cNightPvP: Diese Crate existiert nicht."));
            return;
        }

        if (isOpening(player)) {
            player.sendMessage(color("&cNightPvP: Du öffnest bereits eine Crate."));
            return;
        }

        ItemStack item = player.getInventory().getItemInMainHand();
        String itemCrateId = getCrateId(item);

        if (itemCrateId == null || !itemCrateId.equalsIgnoreCase(crateId)) {
            player.sendMessage(color("&cNightPvP: Du hältst diese Crate nicht mehr in der Hand."));
            cleanup(player);
            return;
        }

        List<NightPvPCrateReward> rewards = getRewards(crateId);
        if (rewards.isEmpty()) {
            player.sendMessage(color("&cNightPvP: Keine Belohnungen konfiguriert."));
            return;
        }

        NightPvPCrateReward winner = chooseWinner(rewards);
        consumeOne(player);

        if (!withAnimation) {
            giveReward(player, winner);
            player.playSound(
                    player.getLocation(),
                    Sound.ENTITY_PLAYER_LEVELUP,
                    1.0f,
                    1.0f
            );
            player.sendTitle(
                    color("&a&lGEWONNEN!"),
                    color("&f" + rewardText(winner)),
                    5,
                    30,
                    10
            );
            cleanup(player);
            return;
        }

        startThreeRowAnimation(player, crateId, rewards, winner);
    }

    private void startThreeRowAnimation(
            Player player,
            String crateId,
            List<NightPvPCrateReward> rewards,
            NightPvPCrateReward winner
    ) {
        opening.add(player.getUniqueId());
        menuType.put(player.getUniqueId(), MenuType.OPENING);

        Inventory inventory = Bukkit.createInventory(
                player,
                27,
                color(plugin.getConfig().getString(
                        "crates." + crateId + ".settings.open-title",
                        "&8&lNightPvP &r&7» &fCrate"
                ))
        );

        Material borderMaterial = materialOrDefault(
                plugin.getConfig().getString(
                        "crates." + crateId + ".settings.border-material",
                        "BLACK_STAINED_GLASS_PANE"
                ),
                Material.BLACK_STAINED_GLASS_PANE
        );

        ItemStack border = simple(borderMaterial, color("&0"));

        // Obere und untere Reihe als Rahmen.
        for (int slot = 0; slot <= 8; slot++) {
            inventory.setItem(slot, border);
        }
        for (int slot = 18; slot <= 26; slot++) {
            inventory.setItem(slot, border);
        }

        // Markierung direkt oberhalb und unterhalb des Hauptgewinn-Slots.
        Material markerMaterial = materialOrDefault(
                plugin.getConfig().getString(
                        "crates." + crateId + ".settings.center-marker-material",
                        "YELLOW_STAINED_GLASS_PANE"
                ),
                Material.YELLOW_STAINED_GLASS_PANE
        );

        inventory.setItem(4, simple(
                markerMaterial,
                color("&e&l▼ HAUPTGEWINN ▼")
        ));
        inventory.setItem(22, simple(
                markerMaterial,
                color("&e&l▲ HAUPTGEWINN ▲")
        ));

        player.openInventory(inventory);

        int steps = Math.max(
                12,
                plugin.getConfig().getInt(
                        "crates." + crateId + ".settings.animation-steps",
                        45
                )
        );

        long speed = Math.max(
                1L,
                plugin.getConfig().getLong(
                        "crates." + crateId + ".settings.animation-speed",
                        2L
                )
        );

        new BukkitRunnable() {
            private int step = 0;
            private int offset = 0;

            @Override
            public void run() {
                if (!player.isOnline() || !isOpening(player)) {
                    cancel();
                    return;
                }

                if (step >= steps) {
                    finishAnimation(
                            player,
                            crateId,
                            inventory,
                            rewards,
                            winner
                    );
                    cancel();
                    return;
                }

                // Mittlere Reihe: Slots 9 bis 17.
                // Die Items laufen von rechts nach links durch.
                for (int column = 0; column < 9; column++) {
                    int rewardIndex =
                            Math.floorMod(offset + column, rewards.size());

                    NightPvPCrateReward reward =
                            rewards.get(rewardIndex);

                    inventory.setItem(
                            9 + column,
                            createRewardIcon(reward, false)
                    );
                }

                if (plugin.getConfig().getBoolean(
                        "crates." + crateId + ".settings.animation-sound",
                        true
                )) {
                    player.playSound(
                            player.getLocation(),
                            Sound.UI_BUTTON_CLICK,
                            0.45f,
                            0.9f + ((step % 6) * 0.08f)
                    );
                }

                offset++;
                step++;
            }
        }.runTaskTimer(plugin, 0L, speed);
    }

    private void finishAnimation(
            Player player,
            String crateId,
            Inventory inventory,
            List<NightPvPCrateReward> rewards,
            NightPvPCrateReward winner
    ) {
        // Die mittlere Reihe bleibt sichtbar.
        // Slot 13 ist die Mitte und zeigt garantiert den ausgelosten Hauptgewinn.
        int winnerIndex = rewards.indexOf(winner);

        for (int column = 0; column < 9; column++) {
            int relative = column - 4;
            int rewardIndex =
                    Math.floorMod(winnerIndex + relative, rewards.size());

            NightPvPCrateReward reward =
                    rewards.get(rewardIndex);

            inventory.setItem(
                    9 + column,
                    createRewardIcon(
                            reward,
                            column == 4
                    )
            );
        }

        giveReward(player, winner);

        if (plugin.getConfig().getBoolean(
                "crates." + crateId + ".settings.win-sound",
                true
        )) {
            player.playSound(
                    player.getLocation(),
                    Sound.ENTITY_PLAYER_LEVELUP,
                    1.0f,
                    1.0f
            );
        }

        player.sendTitle(
                color(plugin.getConfig().getString(
                        "crates." + crateId + ".settings.win-title",
                        "&a&lGEWONNEN!"
                )),
                color(plugin.getConfig().getString(
                        "crates." + crateId + ".settings.win-subtitle",
                        "&f%reward%"
                )).replace("%reward%", rewardText(winner)),
                5,
                30,
                10
        );

        long closeDelay = Math.max(
                1L,
                plugin.getConfig().getLong(
                        "crates." + crateId + ".settings.close-delay",
                        50L
                )
        );

        new BukkitRunnable() {
            @Override
            public void run() {
                if (player.isOnline()) {
                    player.closeInventory();
                }

                cleanup(player);
            }
        }.runTaskLater(plugin, closeDelay);
    }

    public void handleClose(Player player) {
        if (!isOpening(player)) {
            cleanup(player);
        }
    }

    private List<NightPvPCrateReward> getRewards(String crateId) {
        List<NightPvPCrateReward> rewards = new ArrayList<>();

        ConfigurationSection section =
                plugin.getConfig().getConfigurationSection(
                        "crates." + crateId + ".rewards"
                );

        if (section == null) {
            return rewards;
        }

        for (String rewardId : section.getKeys(false)) {
            String path =
                    "crates." + crateId + ".rewards." + rewardId;

            rewards.add(new NightPvPCrateReward(
                    rewardId,
                    plugin.getConfig().getString(path + ".type", "item"),
                    plugin.getConfig().getString(path + ".value", "DIRT"),
                    Math.max(
                            1,
                            plugin.getConfig().getInt(path + ".amount", 1)
                    ),
                    Math.max(
                            0.0,
                            plugin.getConfig().getDouble(path + ".chance", 0.0)
                    )
            ));
        }

        return rewards;
    }

    private NightPvPCrateReward chooseWinner(
            List<NightPvPCrateReward> rewards
    ) {
        double total = 0.0;

        for (NightPvPCrateReward reward : rewards) {
            total += reward.chance();
        }

        if (total <= 0.0) {
            return rewards.get(random.nextInt(rewards.size()));
        }

        double roll = random.nextDouble() * total;
        double current = 0.0;

        for (NightPvPCrateReward reward : rewards) {
            current += reward.chance();

            if (roll <= current) {
                return reward;
            }
        }

        return rewards.get(rewards.size() - 1);
    }

    private ItemStack createRewardIcon(
            NightPvPCrateReward reward,
            boolean winner
    ) {
        Material material;

        if (reward.type().equalsIgnoreCase("money")) {
            material = Material.GOLD_INGOT;
        } else if (reward.type().equalsIgnoreCase("command")) {
            material = Material.ENCHANTED_BOOK;
        } else {
            Material matched =
                    Material.matchMaterial(
                            reward.value().toUpperCase(Locale.ROOT)
                    );

            material = matched == null
                    ? Material.CHEST
                    : matched;
        }

        ItemStack item = new ItemStack(
                material,
                Math.max(
                        1,
                        Math.min(
                                reward.amount(),
                                material.getMaxStackSize()
                        )
                )
        );

        ItemMeta meta = item.getItemMeta();

        if (meta != null) {
            meta.setDisplayName(
                    winner
                            ? color("&6&l★ NIGHTPVP HAUPTGEWINN ★")
                            : color("&f" + rewardText(reward))
            );

            meta.setLore(List.of(
                    color("&7Gewinnchance: &e"
                            + formatChance(reward.chance())
                            + "%"),
                    color("&7Menge: &f" + reward.amount()),
                    color("&8"),
                    winner
                            ? color("&a&lDEIN GEWINN")
                            : color("&d&lNightPvP")
            ));

            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            item.setItemMeta(meta);
        }

        return item;
    }

    private void giveReward(
            Player player,
            NightPvPCrateReward reward
    ) {
        if (reward.type().equalsIgnoreCase("item")) {
            Material material =
                    Material.matchMaterial(
                            reward.value().toUpperCase(Locale.ROOT)
                    );

            if (material == null) {
                player.sendMessage(
                        color("&cNightPvP: Unbekanntes Item: "
                                + reward.value())
                );
                return;
            }

            Map<Integer, ItemStack> leftovers =
                    player.getInventory().addItem(
                            new ItemStack(
                                    material,
                                    reward.amount()
                            )
                    );

            for (ItemStack leftover : leftovers.values()) {
                player.getWorld().dropItemNaturally(
                        player.getLocation(),
                        leftover
                );
            }

            player.sendMessage(
                    color("&aNightPvP: &f"
                            + reward.amount()
                            + "x "
                            + reward.value()
                            + " &agewonnen.")
            );
            return;
        }

        if (reward.type().equalsIgnoreCase("money")) {
            String commandTemplate =
                    plugin.getConfig().getString(
                            "money-reward-command",
                            "guthaben give %player% %amount%"
                    );

            String command = commandTemplate
                    .replace("%player%", player.getName())
                    .replace("%amount%", reward.value());

            Bukkit.dispatchCommand(
                    Bukkit.getConsoleSender(),
                    command
            );

            player.sendMessage(
                    color("&aNightPvP: &f"
                            + reward.value()
                            + plugin.getConfig().getString(
                                    "economy.symbol",
                                    "$"
                            )
                            + " &agewonnen.")
            );
            return;
        }

        if (reward.type().equalsIgnoreCase("command")) {
            Bukkit.dispatchCommand(
                    Bukkit.getConsoleSender(),
                    reward.value()
                            .replace("%player%", player.getName())
            );

            player.sendMessage(
                    color("&aNightPvP: Sonderbelohnung gewonnen.")
            );
        }
    }

    private String rewardText(NightPvPCrateReward reward) {
        if (reward.type().equalsIgnoreCase("money")) {
            return reward.value()
                    + plugin.getConfig().getString(
                            "economy.symbol",
                            "$"
                    );
        }

        if (reward.type().equalsIgnoreCase("item")) {
            return reward.amount()
                    + "x "
                    + reward.value();
        }

        return "Sonderbelohnung";
    }

    private String formatChance(double chance) {
        if (chance == Math.rint(chance)) {
            return String.format(
                    Locale.US,
                    "%.0f",
                    chance
            );
        }

        return String.format(
                Locale.US,
                "%.2f",
                chance
        );
    }

    private Material materialOrDefault(
            String materialName,
            Material fallback
    ) {
        Material material = Material.matchMaterial(
                materialName == null
                        ? ""
                        : materialName
        );

        return material == null
                ? fallback
                : material;
    }

    private void consumeOne(Player player) {
        ItemStack item =
                player.getInventory().getItemInMainHand();

        if (item.getAmount() <= 1) {
            player.getInventory().setItemInMainHand(null);
        } else {
            item.setAmount(item.getAmount() - 1);
        }
    }

    private void fill(
            Inventory inventory,
            Material material
    ) {
        ItemStack filler =
                simple(material, color("&0"));

        for (int slot = 0; slot < inventory.getSize(); slot++) {
            inventory.setItem(slot, filler);
        }
    }

    private ItemStack simple(
            Material material,
            String name,
            String... lore
    ) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();

        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(List.of(lore));
            item.setItemMeta(meta);
        }

        return item;
    }

    private void cleanup(Player player) {
        opening.remove(player.getUniqueId());
        activeCrate.remove(player.getUniqueId());
        menuType.remove(player.getUniqueId());
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes(
                '&',
                text == null ? "" : text
        );
    }
}
