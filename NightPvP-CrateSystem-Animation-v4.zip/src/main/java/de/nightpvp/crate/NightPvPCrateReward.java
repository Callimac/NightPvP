package de.nightpvp.crate;

public record NightPvPCrateReward(
        String id,
        String type,
        String value,
        int amount,
        double chance
) {
}
