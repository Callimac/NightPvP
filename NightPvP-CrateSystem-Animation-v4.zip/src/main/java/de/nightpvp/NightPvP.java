package de.nightpvp;

import de.nightpvp.command.NightPvPCrateCommand;
import de.nightpvp.crate.NightPvPCrateManager;
import de.nightpvp.listener.NightPvPCrateInventoryListener;
import de.nightpvp.listener.NightPvPCrateListener;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class NightPvP extends JavaPlugin {

    private NightPvPCrateManager crateManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        crateManager = new NightPvPCrateManager(this);

        NightPvPCrateCommand command = new NightPvPCrateCommand(crateManager);
        PluginCommand crate = getCommand("crate");

        if (crate != null) {
            crate.setExecutor(command);
            crate.setTabCompleter(command);
        } else {
            getLogger().severe("Command /crate fehlt in plugin.yml.");
        }

        getServer().getPluginManager().registerEvents(
                new NightPvPCrateListener(crateManager), this
        );
        getServer().getPluginManager().registerEvents(
                new NightPvPCrateInventoryListener(crateManager), this
        );

        getLogger().info("NightPvP Crate-System aktiviert.");
    }

    @Override
    public void onDisable() {
        if (crateManager != null) {
            crateManager.shutdown();
        }
    }
}
