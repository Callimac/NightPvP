package de.nightpvp.listener;

import de.nightpvp.crate.NightPvPCrateManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;

public final class NightPvPCrateInventoryListener implements Listener {

    private final NightPvPCrateManager manager;

    public NightPvPCrateInventoryListener(
            NightPvPCrateManager manager
    ) {
        this.manager = manager;
    }

    @EventHandler
    public void onClick(
            InventoryClickEvent event
    ) {
        if (!(event.getWhoClicked()
                instanceof Player player)) {
            return;
        }

        NightPvPCrateManager.MenuType type =
                manager.getMenuType(player);

        if (type == NightPvPCrateManager.MenuType.NONE) {
            return;
        }

        event.setCancelled(true);

        String crateId =
                manager.getActiveCrate(player);

        if (crateId == null) {
            return;
        }

        int slot = event.getRawSlot();

        if (type == NightPvPCrateManager.MenuType.SETTINGS) {
            if (slot == 11) {
                player.closeInventory();
                manager.startOpening(
                        player,
                        crateId,
                        true
                );
                return;
            }

            if (slot == 13) {
                manager.openPreview(
                        player,
                        crateId
                );
                return;
            }

            if (slot == 15) {
                player.closeInventory();
                manager.startOpening(
                        player,
                        crateId,
                        false
                );
                return;
            }

            if (slot == 22) {
                player.closeInventory();
            }

            return;
        }

        if (type == NightPvPCrateManager.MenuType.PREVIEW
                && slot == 49) {
            manager.openSettings(
                    player,
                    crateId
            );
        }
    }

    @EventHandler
    public void onClose(
            InventoryCloseEvent event
    ) {
        if (event.getPlayer()
                instanceof Player player) {
            manager.handleClose(player);
        }
    }
}
