package de.nightpvp.listener;

import de.nightpvp.crate.NightPvPCrateManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public final class NightPvPCrateListener implements Listener {

    private final NightPvPCrateManager manager;

    public NightPvPCrateListener(
            NightPvPCrateManager manager
    ) {
        this.manager = manager;
    }

    @EventHandler
    public void onInteract(
            PlayerInteractEvent event
    ) {
        Action action = event.getAction();

        if (action != Action.RIGHT_CLICK_AIR
                && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        ItemStack item =
                event.getPlayer()
                        .getInventory()
                        .getItemInMainHand();

        String crateId =
                manager.getCrateId(item);

        if (crateId == null) {
            return;
        }

        event.setCancelled(true);

        manager.openSettings(
                event.getPlayer(),
                crateId
        );
    }
}
